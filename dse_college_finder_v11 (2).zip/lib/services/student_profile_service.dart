import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── Search History Entry ──────────────────────────────────────────────────────
class SearchHistoryEntry {
  final String type;        // 'DSE' or 'Diploma'
  final double percentage;
  final String category;
  final String district;
  final String branch;      // used by diploma
  final String capRound;
  final bool isPwd;
  final int resultsCount;
  final DateTime searchedAt;

  SearchHistoryEntry({
    required this.type,
    required this.percentage,
    required this.category,
    required this.district,
    this.branch = '',
    required this.capRound,
    required this.isPwd,
    required this.resultsCount,
    required this.searchedAt,
  });

  Map<String, dynamic> toJson() => {
    'type': type,
    'percentage': percentage,
    'category': category,
    'district': district,
    'branch': branch,
    'capRound': capRound,
    'isPwd': isPwd,
    'resultsCount': resultsCount,
    'searchedAt': searchedAt.toIso8601String(),
  };

  factory SearchHistoryEntry.fromJson(Map<String, dynamic> j) => SearchHistoryEntry(
    type: j['type'] ?? 'DSE',
    percentage: (j['percentage'] as num).toDouble(),
    category: j['category'] ?? 'OPEN',
    district: j['district'] ?? 'All Districts',
    branch: j['branch'] ?? '',
    capRound: j['capRound'] ?? 'CAP1',
    isPwd: j['isPwd'] ?? false,
    resultsCount: j['resultsCount'] ?? 0,
    searchedAt: DateTime.tryParse(j['searchedAt'] ?? '') ?? DateTime.now(),
  );
}

// ── Student Profile ───────────────────────────────────────────────────────────
class StudentProfile {
  String fullName;
  String mobile;
  String email;
  String city;
  String state;
  String category;
  String gender;
  String educationType;     // 'DSE - B.Tech' or 'Diploma - Polytechnic' or 'Both'
  double? percentage;
  String preferredDistrict;
  String preferredBranch;

  StudentProfile({
    this.fullName = '',
    this.mobile = '',
    this.email = '',
    this.city = '',
    this.state = 'Maharashtra',
    this.category = 'OPEN',
    this.gender = 'Not Specified',
    this.educationType = 'DSE - B.Tech',
    this.percentage,
    this.preferredDistrict = 'All Districts',
    this.preferredBranch = 'All Branches',
  });

  Map<String, dynamic> toJson() => {
    'fullName': fullName,
    'mobile': mobile,
    'email': email,
    'city': city,
    'state': state,
    'category': category,
    'gender': gender,
    'educationType': educationType,
    'percentage': percentage,
    'preferredDistrict': preferredDistrict,
    'preferredBranch': preferredBranch,
  };

  factory StudentProfile.fromJson(Map<String, dynamic> j) => StudentProfile(
    fullName: j['fullName'] ?? '',
    mobile: j['mobile'] ?? '',
    email: j['email'] ?? '',
    city: j['city'] ?? '',
    state: j['state'] ?? 'Maharashtra',
    category: j['category'] ?? 'OPEN',
    gender: j['gender'] ?? 'Not Specified',
    educationType: j['educationType'] ?? 'DSE - B.Tech',
    percentage: j['percentage'] == null ? null : (j['percentage'] as num).toDouble(),
    preferredDistrict: j['preferredDistrict'] ?? 'All Districts',
    preferredBranch: j['preferredBranch'] ?? 'All Branches',
  );

  String get initials {
    final parts = fullName.trim().split(' ').where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  bool get isComplete =>
      fullName.trim().isNotEmpty && mobile.trim().isNotEmpty;
}

// ── Service ───────────────────────────────────────────────────────────────────
class StudentProfileService extends ChangeNotifier {
  static const _keyProfile = 'student_profile_v1';
  static const _keyHistory = 'search_history_v1';
  static const int _maxHistory = 30;

  StudentProfile _profile = StudentProfile();
  List<SearchHistoryEntry> _history = [];

  StudentProfile get profile => _profile;
  List<SearchHistoryEntry> get history => List.unmodifiable(_history);

  // ── Load from prefs ─────────────────────────────────────────────────────────
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();

    final profileJson = prefs.getString(_keyProfile);
    if (profileJson != null) {
      try {
        _profile = StudentProfile.fromJson(jsonDecode(profileJson));
      } catch (_) {}
    }

    final historyJson = prefs.getString(_keyHistory);
    if (historyJson != null) {
      try {
        final List<dynamic> list = jsonDecode(historyJson);
        _history = list.map((e) => SearchHistoryEntry.fromJson(e)).toList();
        // Most recent first
        _history.sort((a, b) => b.searchedAt.compareTo(a.searchedAt));
      } catch (_) {}
    }

    notifyListeners();
  }

  // ── Save profile ────────────────────────────────────────────────────────────
  Future<void> saveProfile(StudentProfile updated) async {
    _profile = updated;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyProfile, jsonEncode(updated.toJson()));
    notifyListeners();
  }

  // ── Add search entry ────────────────────────────────────────────────────────
  Future<void> addSearch(SearchHistoryEntry entry) async {
    _history.insert(0, entry);
    if (_history.length > _maxHistory) {
      _history = _history.sublist(0, _maxHistory);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _keyHistory, jsonEncode(_history.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  // ── Clear history ───────────────────────────────────────────────────────────
  Future<void> clearHistory() async {
    _history = [];
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyHistory);
    notifyListeners();
  }

  // ── Delete single entry ─────────────────────────────────────────────────────
  Future<void> deleteEntry(int index) async {
    if (index < 0 || index >= _history.length) return;
    _history.removeAt(index);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _keyHistory, jsonEncode(_history.map((e) => e.toJson()).toList()));
    notifyListeners();
  }
}
