import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/college_model.dart';

class PredictorService {
  static List<CollegeModel> _colleges = [];
  static bool _loaded = false;

  static Future<void> loadData() async {
    if (_loaded) return;
    final raw = await rootBundle.loadString('assets/college_cutoff.json');
    final List<dynamic> list = json.decode(raw) as List<dynamic>;
    _colleges = list
        .map((e) => CollegeModel.fromJson(e as Map<String, dynamic>))
        .toList();
    _loaded = true;
  }

  static List<String> get allDistricts {
    final set = <String>{'All Districts'};
    for (final c in _colleges) {
      set.add(c.district);
    }
    final list = set.toList();
    list.sort();
    list.remove('All Districts');
    return <String>['All Districts'] + list;
  }

  static List<String> get allBranches {
    final set = <String>{'All Branches'};
    for (final c in _colleges) {
      set.add(c.branch);
    }
    final list = set.toList();
    list.sort();
    list.remove('All Branches');
    return <String>['All Branches'] + list;
  }

  static List<PredictionResult> predict({
    required double percentage,
    required String district,
    required String category,
    required bool isPwd,
    required String capRound,
    String branch = 'All Branches',
  }) {
    final double effectivePct = isPwd ? percentage + 5.0 : percentage;
    final results = <PredictionResult>[];

    for (final college in _colleges) {
      if (district != 'All Districts' && college.district != district) continue;
      if (branch != 'All Branches' && college.branch != branch) continue;
      final cutoff = college.getCutoff(capRound, category);
      if (cutoff == null) continue;
      if (effectivePct >= cutoff) {
        results.add(PredictionResult(
          college: college,
          cutoff: cutoff,
          userPercentage: percentage,
          capRound: capRound,
          category: category,
        ));
      }
    }

    results.sort((a, b) => a.margin.compareTo(b.margin));
    return results;
  }
}
