import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/college_model.dart';

class DiplomaCollegeModel {
  final String collegeName;
  final String district;
  final String branch;
  final Map<String, Map<String, double>> cutoffs;

  DiplomaCollegeModel({
    required this.collegeName,
    required this.district,
    required this.branch,
    required this.cutoffs,
  });

  factory DiplomaCollegeModel.fromJson(Map<String, dynamic> json) {
    final rawCutoffs = json['cutoffs'] as Map<String, dynamic>;
    final Map<String, Map<String, double>> parsed = {};
    rawCutoffs.forEach((round, catMap) {
      final Map<String, double> cats = {};
      (catMap as Map<String, dynamic>).forEach((cat, val) {
        cats[cat] = (val as num).toDouble();
      });
      parsed[round] = cats;
    });
    return DiplomaCollegeModel(
      collegeName: (json['college_name'] ?? '') as String,
      district: (json['district'] ?? '') as String,
      branch: (json['branch'] ?? '') as String,
      cutoffs: parsed,
    );
  }

  double? getCutoff(String capRound, String category) {
    return cutoffs[capRound]?[category];
  }
}

class DiplomaResult {
  final DiplomaCollegeModel college;
  final double cutoff;
  final double userPercentage;
  final String capRound;
  final String category;

  DiplomaResult({
    required this.college,
    required this.cutoff,
    required this.userPercentage,
    required this.capRound,
    required this.category,
  });

  double get margin => userPercentage - cutoff;

  String get chanceLabel {
    if (margin >= 10) return 'Strong Chance';
    if (margin >= 5) return 'Good Chance';
    if (margin >= 2) return 'Moderate';
    return 'Very Tight';
  }
}

class DiplomaPredictorService {
  static List<DiplomaCollegeModel> _colleges = [];
  static bool _loaded = false;
  static String loadError = '';
  static int loadedCount = 0;

  static Future<void> loadData() async {
    if (_loaded && _colleges.isNotEmpty) return;
    try {
      final raw = await rootBundle.loadString('assets/diploma_cutoff.json');
      final List<dynamic> list = json.decode(raw) as List<dynamic>;
      _colleges = list
          .map((e) => DiplomaCollegeModel.fromJson(e as Map<String, dynamic>))
          .toList();
      loadedCount = _colleges.length;
      loadError = '';
      _loaded = true;
    } catch (e) {
      loadError = e.toString();
      _loaded = false;
    }
  }

  static bool get isLoaded => _loaded && _colleges.isNotEmpty;

  static List<String> get allDistricts {
    final set = <String>{'All Districts'};
    for (final c in _colleges) {
      if (c.district.isNotEmpty) set.add(c.district);
    }
    final list = set.toList()..sort();
    list.remove('All Districts');
    return <String>['All Districts'] + list;
  }

  static List<String> get allBranches {
    final set = <String>{'All Branches'};
    for (final c in _colleges) {
      if (c.branch.isNotEmpty) set.add(c.branch);
    }
    final list = set.toList()..sort();
    list.remove('All Branches');
    return <String>['All Branches'] + list;
  }

  /// Returns matching results for given round.
  /// If no results found for selected round, also tries other rounds
  /// so user always gets useful suggestions.
  static List<DiplomaResult> predict({
    required double percentage,
    required String district,
    required String branch,
    required String category,
    required bool isPwd,
    required String capRound,
  }) {
    final double effectivePct = isPwd ? percentage + 5.0 : percentage;

    List<DiplomaResult> _searchRound(String round) {
      final results = <DiplomaResult>[];
      for (final college in _colleges) {
        if (district != 'All Districts' && college.district != district) continue;
        if (branch != 'All Branches' && college.branch != branch) continue;
        final cutoff = college.getCutoff(round, category);
        if (cutoff == null) continue;
        if (effectivePct >= cutoff) {
          results.add(DiplomaResult(
            college: college,
            cutoff: cutoff,
            userPercentage: percentage,
            capRound: round,
            category: category,
          ));
        }
      }
      return results;
    }

    // First try selected round
    final results = _searchRound(capRound);
    if (results.isNotEmpty) {
      results.sort((a, b) => a.margin.compareTo(b.margin));
      return results;
    }

    // If no results for selected round, try all other rounds and combine
    final allResults = <DiplomaResult>[];
    for (final round in ['CAP1', 'CAP2', 'CAP3', 'CAP4']) {
      if (round == capRound) continue;
      allResults.addAll(_searchRound(round));
    }
    allResults.sort((a, b) => a.margin.compareTo(b.margin));
    return allResults;
  }
}
