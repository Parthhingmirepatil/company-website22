import 'dart:convert';
import 'package:flutter/services.dart';

class CollegeInfo {
  final String phone;
  final String email;
  final String website;
  final String address;
  final String established;
  final String principal;
  final String affiliation;
  final String mapsUrl;
  final String district;

  CollegeInfo({
    required this.phone,
    required this.email,
    required this.website,
    required this.address,
    required this.established,
    required this.principal,
    required this.affiliation,
    required this.mapsUrl,
    required this.district,
  });

  factory CollegeInfo.fromJson(Map<String, dynamic> j) => CollegeInfo(
        phone:       j['phone']       ?? '',
        email:       j['email']       ?? '',
        website:     j['website']     ?? '',
        address:     j['address']     ?? '',
        established: j['established'] ?? '',
        principal:   j['principal']   ?? '',
        affiliation: j['affiliation'] ?? '',
        mapsUrl:     j['maps_url']    ?? '',
        district:    j['district']    ?? '',
      );
}

class CollegeInfoService {
  static final CollegeInfoService _instance = CollegeInfoService._();
  factory CollegeInfoService() => _instance;
  CollegeInfoService._();

  Map<String, CollegeInfo>? _data;

  Future<void> load() async {
    if (_data != null) return;
    final raw = await rootBundle.loadString('assets/college_info.json');
    final map = jsonDecode(raw) as Map<String, dynamic>;
    _data = map.map((k, v) => MapEntry(k, CollegeInfo.fromJson(v as Map<String, dynamic>)));
  }

  CollegeInfo? getInfo(String collegeName) => _data?[collegeName];

  /// Fuzzy match: tries exact, then partial
  CollegeInfo? findInfo(String collegeName) {
    if (_data == null) return null;
    if (_data!.containsKey(collegeName)) return _data![collegeName];
    // partial match
    for (final key in _data!.keys) {
      if (key.toLowerCase().contains(collegeName.toLowerCase().substring(0, 10))) {
        return _data![key];
      }
    }
    return null;
  }
}
