import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService extends ChangeNotifier {
  bool _isLoggedIn = false;
  String _loggedInUser = '';
  String _errorMessage = '';

  bool get isLoggedIn => _isLoggedIn;
  String get loggedInUser => _loggedInUser;
  String get errorMessage => _errorMessage;

  static const String _prefix = 'dse_user_';
  static const String _keyLogin = 'dse_logged_in';
  static const String _keyCurrent = 'dse_current_user';

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _isLoggedIn = prefs.getBool(_keyLogin) ?? false;
    _loggedInUser = prefs.getString(_keyCurrent) ?? '';
    notifyListeners();
  }

  void clearError() {
    _errorMessage = '';
    notifyListeners();
  }

  Future<bool> register(String username, String password) async {
    _errorMessage = '';
    final u = username.trim();
    final p = password.trim();
    if (u.isEmpty || p.isEmpty) {
      _errorMessage = 'Username and password cannot be empty.';
      notifyListeners();
      return false;
    }
    if (u.length < 3) {
      _errorMessage = 'Username must be at least 3 characters.';
      notifyListeners();
      return false;
    }
    if (p.length < 4) {
      _errorMessage = 'Password must be at least 4 characters.';
      notifyListeners();
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    final key = '$_prefix${u.toLowerCase()}';
    if (prefs.containsKey(key)) {
      _errorMessage = 'Username already exists. Please login.';
      notifyListeners();
      return false;
    }
    await prefs.setString(key, p);
    notifyListeners();
    return true;
  }

  Future<bool> login(String username, String password) async {
    _errorMessage = '';
    final u = username.trim();
    final p = password.trim();
    if (u.isEmpty || p.isEmpty) {
      _errorMessage = 'Please enter username and password.';
      notifyListeners();
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString('$_prefix${u.toLowerCase()}');
    if (stored == null) {
      _errorMessage = 'User not found. Please register first.';
      notifyListeners();
      return false;
    }
    if (stored != p) {
      _errorMessage = 'Incorrect password.';
      notifyListeners();
      return false;
    }
    _isLoggedIn = true;
    _loggedInUser = u;
    await prefs.setBool(_keyLogin, true);
    await prefs.setString(_keyCurrent, u);
    notifyListeners();
    return true;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyLogin, false);
    await prefs.remove(_keyCurrent);
    _isLoggedIn = false;
    _loggedInUser = '';
    _errorMessage = '';
    notifyListeners();
  }
}
