import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/student_profile_service.dart';

class StudentProfileScreen extends StatefulWidget {
  const StudentProfileScreen({super.key});

  @override
  State<StudentProfileScreen> createState() => _StudentProfileScreenState();
}

class _StudentProfileScreenState extends State<StudentProfileScreen> {
  bool _editMode = false;

  // Form controllers
  final _nameCtrl       = TextEditingController();
  final _mobileCtrl     = TextEditingController();
  final _emailCtrl      = TextEditingController();
  final _cityCtrl       = TextEditingController();
  final _pctCtrl        = TextEditingController();

  String _category       = 'OPEN';
  String _gender         = 'Not Specified';
  String _educationType  = 'DSE - B.Tech';
  String _prefDistrict   = 'All Districts';
  String _prefBranch     = 'All Branches';

  static const List<String> _categories    = ['OPEN', 'SC', 'ST', 'VJNT', 'SBC', 'OBC', 'EWS'];
  static const List<String> _genders       = ['Not Specified', 'Male', 'Female', 'Other'];
  static const List<String> _eduTypes      = ['DSE - B.Tech', 'Diploma - Polytechnic', 'Both'];

  @override
  void initState() {
    super.initState();
    _loadFromProfile();
  }

  void _loadFromProfile() {
    final p = context.read<StudentProfileService>().profile;
    _nameCtrl.text    = p.fullName;
    _mobileCtrl.text  = p.mobile;
    _emailCtrl.text   = p.email;
    _cityCtrl.text    = p.city;
    _pctCtrl.text     = p.percentage?.toString() ?? '';
    _category         = p.category;
    _gender           = p.gender;
    _educationType    = p.educationType;
    _prefDistrict     = p.preferredDistrict;
    _prefBranch       = p.preferredBranch;
  }

  Future<void> _saveProfile() async {
    final svc = context.read<StudentProfileService>();
    final updated = StudentProfile(
      fullName:          _nameCtrl.text.trim(),
      mobile:            _mobileCtrl.text.trim(),
      email:             _emailCtrl.text.trim(),
      city:              _cityCtrl.text.trim(),
      state:             'Maharashtra',
      category:          _category,
      gender:            _gender,
      educationType:     _educationType,
      percentage:        double.tryParse(_pctCtrl.text.trim()),
      preferredDistrict: _prefDistrict,
      preferredBranch:   _prefBranch,
    );
    await svc.saveProfile(updated);
    setState(() => _editMode = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Row(children: [
            Icon(Icons.check_circle, color: Colors.white),
            SizedBox(width: 8),
            Text('Profile saved successfully!'),
          ]),
          backgroundColor: Color(0xFF2E7D32),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _mobileCtrl.dispose(); _emailCtrl.dispose();
    _cityCtrl.dispose(); _pctCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<StudentProfileService>(
      builder: (context, svc, _) {
        final p       = svc.profile;
        final history = svc.history;

        return Scaffold(
          backgroundColor: const Color(0xFFF0F4FF),
          body: CustomScrollView(
            slivers: [

              // ── Gradient SliverAppBar ────────────────────────────────────
              SliverAppBar(
                expandedHeight: 230,
                pinned: true,
                backgroundColor: const Color(0xFF1565C0),
                iconTheme: const IconThemeData(color: Colors.white),
                title: Text(
                  _editMode ? 'Edit My Profile' : 'My Profile',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                actions: [
                  if (!_editMode)
                    IconButton(
                      icon: const Icon(Icons.edit_rounded, color: Colors.white),
                      tooltip: 'Edit Profile',
                      onPressed: () => setState(() => _editMode = true),
                    )
                  else ...[
                    TextButton.icon(
                      onPressed: () {
                        _loadFromProfile();
                        setState(() => _editMode = false);
                      },
                      icon: const Icon(Icons.close, color: Colors.white70, size: 18),
                      label: const Text('Cancel', style: TextStyle(color: Colors.white70)),
                    ),
                    TextButton.icon(
                      onPressed: _saveProfile,
                      icon: const Icon(Icons.save_rounded, color: Colors.greenAccent, size: 18),
                      label: const Text('Save', style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF0D47A1), Color(0xFF1565C0), Color(0xFF1E88E5)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: SafeArea(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(height: 44),
                          // Avatar
                          Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              Container(
                                width: 84,
                                height: 84,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(color: Colors.white, width: 3),
                                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 12, offset: const Offset(0, 4))],
                                ),
                                child: Center(
                                  child: Text(
                                    p.initials,
                                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Color(0xFF1565C0)),
                                  ),
                                ),
                              ),
                              if (_editMode)
                                Container(
                                  width: 26, height: 26,
                                  decoration: const BoxDecoration(color: Colors.greenAccent, shape: BoxShape.circle),
                                  child: const Icon(Icons.edit, size: 14, color: Color(0xFF1A237E)),
                                ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            p.fullName.isEmpty ? 'Add Your Name →' : p.fullName,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: p.fullName.isEmpty ? Colors.white38 : Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          // Quick stat chips
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _headerChip(Icons.category_outlined, p.category),
                              const SizedBox(width: 6),
                              if (p.percentage != null)
                                _headerChip(Icons.percent_rounded, '${p.percentage!.toStringAsFixed(1)}%'),
                              const SizedBox(width: 6),
                              _headerChip(Icons.history_rounded, '${history.length} searches'),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      // ── Completion banner (when incomplete + not editing) ──
                      if (!p.isComplete && !_editMode) ...[
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF8E1),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFFFFCA28)),
                          ),
                          child: Row(children: [
                            const Icon(Icons.info_rounded, color: Color(0xFFF57F17), size: 20),
                            const SizedBox(width: 10),
                            const Expanded(
                              child: Text(
                                'Complete your profile so we can personalise your experience!',
                                style: TextStyle(fontSize: 13, color: Color(0xFF5D4037)),
                              ),
                            ),
                            TextButton(
                              onPressed: () => setState(() => _editMode = true),
                              child: const Text('Fill Now', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                            ),
                          ]),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // ── Personal Info Card ───────────────────────────────
                      _sectionLabel('Personal Information', Icons.person_outline_rounded),
                      const SizedBox(height: 10),
                      _profileCard(children: [
                        _editMode
                          ? _inputField('Full Name', Icons.person_rounded, _nameCtrl, hint: 'e.g. Rahul Sharma')
                          : _infoRow(Icons.person_rounded, 'Full Name', p.fullName.isEmpty ? 'Not set' : p.fullName, empty: p.fullName.isEmpty),
                        _divider(),
                        _editMode
                          ? _inputField('Mobile Number', Icons.phone_rounded, _mobileCtrl, hint: '10-digit mobile', keyboard: TextInputType.phone)
                          : _infoRow(Icons.phone_rounded, 'Mobile', p.mobile.isEmpty ? 'Not set' : p.mobile, empty: p.mobile.isEmpty),
                        _divider(),
                        _editMode
                          ? _inputField('Email Address', Icons.email_rounded, _emailCtrl, hint: 'e.g. rahul@gmail.com', keyboard: TextInputType.emailAddress)
                          : _infoRow(Icons.email_rounded, 'Email', p.email.isEmpty ? 'Not set' : p.email, empty: p.email.isEmpty),
                        _divider(),
                        _editMode
                          ? _inputField('City / Town', Icons.location_city_rounded, _cityCtrl, hint: 'e.g. Pune')
                          : _infoRow(Icons.location_city_rounded, 'City', p.city.isEmpty ? 'Not set' : '${p.city}, ${p.state}', empty: p.city.isEmpty),
                        _divider(),
                        _editMode
                          ? _dropRow('Gender', Icons.wc_rounded, _gender, _genders, (v) => setState(() => _gender = v!))
                          : _infoRow(Icons.wc_rounded, 'Gender', p.gender),
                      ]),
                      const SizedBox(height: 20),

                      // ── Academic Info Card ───────────────────────────────
                      _sectionLabel('Academic Details', Icons.school_rounded),
                      const SizedBox(height: 10),
                      _profileCard(children: [
                        _editMode
                          ? _inputField('Diploma / SSC Percentage (%)', Icons.percent_rounded, _pctCtrl,
                              hint: 'e.g. 75.50', keyboard: const TextInputType.numberWithOptions(decimal: true))
                          : _infoRow(Icons.percent_rounded, 'Percentage',
                              p.percentage == null ? 'Not set' : '${p.percentage!.toStringAsFixed(2)}%',
                              empty: p.percentage == null, highlight: p.percentage != null),
                        _divider(),
                        _editMode
                          ? _dropRow('Category', Icons.category_outlined, _category, _categories, (v) => setState(() => _category = v!))
                          : _infoRow(Icons.category_outlined, 'Category', p.category, highlight: true),
                        _divider(),
                        _editMode
                          ? _dropRow('Seeking Admission In', Icons.menu_book_rounded, _educationType, _eduTypes, (v) => setState(() => _educationType = v!))
                          : _infoRow(Icons.menu_book_rounded, 'Admission Type', p.educationType),
                      ]),
                      const SizedBox(height: 20),

                      // ── Preferences Card ─────────────────────────────────
                      _sectionLabel('Preferences', Icons.tune_rounded),
                      const SizedBox(height: 10),
                      _profileCard(children: [
                        _editMode
                          ? _dropRow('Preferred District', Icons.location_on_rounded, _prefDistrict,
                              const ['All Districts', 'Pune', 'Mumbai', 'Nashik', 'Aurangabad', 'Nagpur', 'Amravati', 'Solapur', 'Kolhapur', 'Akola', 'Latur', 'Other'],
                              (v) => setState(() => _prefDistrict = v!))
                          : _infoRow(Icons.location_on_rounded, 'Preferred District', p.preferredDistrict),
                        _divider(),
                        _editMode
                          ? _dropRow('Preferred Branch', Icons.engineering_rounded, _prefBranch,
                              const ['All Branches', 'Computer Engineering', 'Mechanical Engineering', 'Civil Engineering',
                                'Electronics & Telecommunication', 'Electrical Engineering', 'Information Technology',
                                'Chemical Engineering', 'Automobile Engineering', 'Other'],
                              (v) => setState(() => _prefBranch = v!))
                          : _infoRow(Icons.engineering_rounded, 'Preferred Branch', p.preferredBranch),
                      ]),
                      const SizedBox(height: 24),

                      // ── Save button (edit mode) ──────────────────────────
                      if (_editMode) ...[
                        SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: ElevatedButton.icon(
                            onPressed: _saveProfile,
                            icon: const Icon(Icons.save_rounded, size: 20),
                            label: const Text('Save Profile', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF1565C0),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              elevation: 4,
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],

                      // ── Search History Section ───────────────────────────
                      Row(
                        children: [
                          _sectionLabel('College Search History', Icons.history_rounded),
                          const Spacer(),
                          if (history.isNotEmpty)
                            TextButton.icon(
                              onPressed: () => _confirmClearHistory(svc),
                              icon: const Icon(Icons.delete_sweep_rounded, size: 16, color: Colors.red),
                              label: const Text('Clear All', style: TextStyle(color: Colors.red, fontSize: 12)),
                              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4)),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),

                      if (history.isEmpty)
                        _emptyHistory()
                      else
                        ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: history.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (_, i) => _historyCard(history[i], i, svc),
                        ),

                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Widget helpers ───────────────────────────────────────────────────────────

  Widget _sectionLabel(String title, IconData icon) => Row(
    children: [
      Icon(icon, size: 18, color: const Color(0xFF1565C0)),
      const SizedBox(width: 8),
      Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
    ],
  );

  Widget _profileCard({required List<Widget> children}) => Card(
    elevation: 2,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    color: Colors.white,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(children: children),
    ),
  );

  Widget _divider() => const Divider(height: 1, indent: 16, endIndent: 16);

  Widget _infoRow(IconData icon, String label, String value, {bool empty = false, bool highlight = false}) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(children: [
        Icon(icon, size: 18, color: const Color(0xFF1565C0)),
        const SizedBox(width: 12),
        Text(label, style: const TextStyle(fontSize: 13, color: Colors.black54)),
        const Spacer(),
        empty
          ? const Text('Not set', style: TextStyle(fontSize: 13, color: Colors.grey, fontStyle: FontStyle.italic))
          : highlight
            ? Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(color: const Color(0xFF1565C0).withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                child: Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF1565C0))),
              )
            : Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.black87)),
      ]),
    );

  Widget _inputField(String label, IconData icon, TextEditingController ctrl,
      {String hint = '', TextInputType keyboard = TextInputType.text}) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: TextField(
        controller: ctrl,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: Icon(icon, color: const Color(0xFF1565C0), size: 20),
          filled: true,
          fillColor: const Color(0xFFF5F7FF),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade200)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF1565C0))),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
      ),
    );

  Widget _dropRow(String label, IconData icon, String value, List<String> items, ValueChanged<String?> onChanged) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF5F7FF),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon, color: const Color(0xFF1565C0), size: 20),
            border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none,
          ),
          items: items.map((e) => DropdownMenuItem(value: e, child: Text(e, style: const TextStyle(fontSize: 14)))).toList(),
          onChanged: onChanged,
          isExpanded: true,
          dropdownColor: Colors.white,
        ),
      ),
    );

  Widget _headerChip(IconData icon, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 12, color: Colors.white70),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 11, color: Colors.white)),
    ]),
  );

  // ── Search History Card ──────────────────────────────────────────────────────
  Widget _historyCard(SearchHistoryEntry entry, int index, StudentProfileService svc) {
    final isDse     = entry.type == 'DSE';
    final cardColor = isDse ? const Color(0xFF1A237E) : const Color(0xFF00695C);
    final bg        = isDse ? const Color(0xFFE8EAF6) : const Color(0xFFE0F2F1);
    final when      = _formatDate(entry.searchedAt);

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: cardColor.withOpacity(0.15)),
      ),
      color: Colors.white,
      child: Column(
        children: [
          // Header strip
          Container(
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(children: [
              Icon(isDse ? Icons.school_rounded : Icons.menu_book_rounded, color: Colors.white, size: 16),
              const SizedBox(width: 8),
              Text(
                isDse ? 'DSE – B.Tech Search' : 'Diploma – Polytechnic Search',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const Spacer(),
              Text(when, style: const TextStyle(color: Colors.white60, fontSize: 11)),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => svc.deleteEntry(index),
                child: const Icon(Icons.close_rounded, color: Colors.white54, size: 18),
              ),
            ]),
          ),

          // Details
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Chips row
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _chip('${entry.percentage.toStringAsFixed(1)}%', Icons.percent_rounded, cardColor),
                    _chip(entry.category, Icons.category_outlined, cardColor),
                    _chip(entry.capRound, Icons.layers_rounded, cardColor),
                    if (entry.isPwd) _chip('PWD', Icons.accessibility_new, Colors.orange),
                  ],
                ),
                const SizedBox(height: 12),

                // District & Branch
                _historyRow(Icons.location_on_rounded, 'District', entry.district, cardColor),
                if (entry.branch.isNotEmpty && entry.branch != 'All Branches') ...[
                  const SizedBox(height: 6),
                  _historyRow(Icons.engineering_rounded, 'Branch', entry.branch, cardColor),
                ],

                const SizedBox(height: 12),
                const Divider(height: 1),
                const SizedBox(height: 10),

                // Result count
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
                        child: Icon(Icons.account_balance_rounded, size: 16, color: cardColor),
                      ),
                      const SizedBox(width: 10),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(
                          '${entry.resultsCount} Colleges Found',
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: cardColor),
                        ),
                        Text('Eligible based on your marks', style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                      ]),
                    ]),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.check_circle_rounded, size: 12, color: cardColor),
                        const SizedBox(width: 4),
                        Text('Searched', style: TextStyle(fontSize: 11, color: cardColor, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String label, IconData icon, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: color.withOpacity(0.09), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 12, color: color),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
    ]),
  );

  Widget _historyRow(IconData icon, String label, String value, Color color) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Icon(icon, size: 15, color: color),
      const SizedBox(width: 6),
      Text('$label: ', style: const TextStyle(fontSize: 12, color: Colors.grey)),
      Expanded(child: Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black87))),
    ],
  );

  Widget _emptyHistory() => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(vertical: 36),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.grey.shade200),
    ),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: const Color(0xFF1565C0).withOpacity(0.07), shape: BoxShape.circle),
        child: const Icon(Icons.search_off_rounded, size: 40, color: Color(0xFF1565C0)),
      ),
      const SizedBox(height: 14),
      const Text('No Searches Yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
      const SizedBox(height: 6),
      const Text(
        'Your DSE and Diploma college searches\nwill appear here automatically.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 13, color: Colors.grey, height: 1.5),
      ),
    ]),
  );

  void _confirmClearHistory(StudentProfileService svc) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Clear Search History'),
        content: const Text('All your search history will be deleted. This action cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () { Navigator.pop(context); svc.clearHistory(); },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now   = DateTime.now();
    final diff  = now.difference(dt);
    if (diff.inMinutes < 1)  return 'Just now';
    if (diff.inHours < 1)    return '${diff.inMinutes}m ago';
    if (diff.inHours < 24)   return '${diff.inHours}h ago';
    if (diff.inDays < 7)     return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
