import 'package:flutter/material.dart';
import '../models/college_model.dart';
import 'college_detail_screen.dart';

class ResultScreen extends StatefulWidget {
  final List<PredictionResult> results;
  final double percentage;
  final String district, category, capRound;
  final bool isPwd;

  const ResultScreen({
    super.key,
    required this.results,
    required this.percentage,
    required this.district,
    required this.category,
    required this.capRound,
    required this.isPwd,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  String _search = '';
  String _sort = 'Margin';

  List<PredictionResult> get _filtered {
    List<PredictionResult> list = widget.results.toList();
    if (_search.isNotEmpty) {
      final q = _search.toLowerCase();
      list = list.where((r) =>
        r.college.collegeName.toLowerCase().contains(q) ||
        r.college.branch.toLowerCase().contains(q) ||
        r.college.district.toLowerCase().contains(q)).toList();
    }
    switch (_sort) {
      case 'Margin': list.sort((a, b) => a.margin.compareTo(b.margin)); break;
      case 'Cutoff': list.sort((a, b) => b.cutoff.compareTo(a.cutoff)); break;
      case 'College': list.sort((a, b) => a.college.collegeName.compareTo(b.college.collegeName)); break;
      case 'District': list.sort((a, b) => a.college.district.compareTo(b.college.district)); break;
    }
    return list;
  }

  Color _color(double m) {
    if (m <= 1) return const Color(0xFFD32F2F);
    if (m <= 3) return const Color(0xFFE65100);
    if (m <= 7) return const Color(0xFF2E7D32);
    return const Color(0xFF1565C0);
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Results', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text('${widget.percentage}% | ${widget.category} | ${widget.capRound}${widget.isPwd ? ' | PWD' : ''}',
              style: const TextStyle(fontSize: 11, color: Colors.white70)),
        ]),
        actions: [
          Container(margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)),
            child: Text('${filtered.length} found', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
        ],
      ),
      body: Column(children: [
        // Stats
        Container(color: const Color(0xFF1A237E), padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Row(children: [
            _chip('✅ Eligible', '${widget.results.length}', Colors.greenAccent),
            const SizedBox(width: 8),
            _chip('📍', widget.district.length > 10 ? widget.district.substring(0, 9) + '…' : widget.district, Colors.lightBlueAccent),
            const SizedBox(width: 8),
            _chip('📊 Your %', '${widget.percentage}%', Colors.yellowAccent),
          ])),
        // Search + Sort
        Container(color: Colors.white, padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Column(children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Search college, branch or district...',
                prefixIcon: const Icon(Icons.search, size: 20),
                filled: true, fillColor: const Color(0xFFF5F5F5),
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none)),
              onChanged: (v) => setState(() => _search = v),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                const Text('Sort: ', style: TextStyle(fontSize: 12, color: Colors.grey)),
                ...['Margin', 'Cutoff', 'College', 'District'].map((s) => GestureDetector(
                  onTap: () => setState(() => _sort = s),
                  child: Container(
                    margin: const EdgeInsets.only(left: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: _sort == s ? const Color(0xFF1A237E) : const Color(0xFFF0F0F0),
                      borderRadius: BorderRadius.circular(20)),
                    child: Text(s, style: TextStyle(
                      fontSize: 12,
                      color: _sort == s ? Colors.white : Colors.black87,
                      fontWeight: _sort == s ? FontWeight.bold : FontWeight.normal)),
                  ),
                )),
              ]),
            ),
          ])),
        // List
        Expanded(
          child: filtered.isEmpty ? _empty() : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: filtered.length,
            itemBuilder: (ctx, i) {
              final r = filtered[i];
              final c = _color(r.margin);
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => CollegeDetailScreen(
                    college: r.college,
                    userPercentage: r.userPercentage,
                    userCategory: r.category,
                  ),
                )),
                child: Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border(left: BorderSide(color: c, width: 4))),
                  padding: const EdgeInsets.all(14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(width: 32, height: 32,
                        decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.1), shape: BoxShape.circle),
                        alignment: Alignment.center,
                        child: Text('${i+1}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1A237E), fontSize: 12))),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(r.college.collegeName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF1A237E))),
                        const SizedBox(height: 2),
                        Row(children: [
                          const Icon(Icons.location_on_outlined, size: 12, color: Colors.grey),
                          const SizedBox(width: 2),
                          Text(r.college.district, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                        ]),
                      ])),
                      Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
                        child: Text(r.chanceLabel, style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 10))),
                    ]),
                    const SizedBox(height: 10),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xFFE8EAF6), borderRadius: BorderRadius.circular(8)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.engineering_outlined, size: 13, color: Color(0xFF3949AB)),
                        const SizedBox(width: 4),
                        Flexible(child: Text(r.college.branch,
                          style: const TextStyle(fontSize: 12, color: Color(0xFF3949AB), fontWeight: FontWeight.w500),
                          overflow: TextOverflow.ellipsis)),
                      ])),
                    const SizedBox(height: 10),
                    const Divider(height: 1),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('Cutoff (${r.category}): ${r.cutoff.toStringAsFixed(2)}%', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                          Text('You: ${r.userPercentage.toStringAsFixed(2)}%', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
                        ]),
                        const SizedBox(height: 4),
                        ClipRRect(borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: (r.cutoff / 100).clamp(0.0, 1.0),
                            backgroundColor: Colors.grey.shade200,
                            valueColor: AlwaysStoppedAnimation<Color>(c),
                            minHeight: 6)),
                      ])),
                      const SizedBox(width: 12),
                      Column(children: [
                        Text('+${r.margin.toStringAsFixed(1)}%', style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 14)),
                        Text('margin', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
                      ]),
                    ]),
                    const SizedBox(height: 6),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text('${r.capRound} Cutoff', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                      Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.08), borderRadius: BorderRadius.circular(4)),
                        child: Text(r.category, style: const TextStyle(fontSize: 10, color: Color(0xFF1A237E), fontWeight: FontWeight.bold))),
                    ]),
                  ]),
                ),
              ),
              ); // GestureDetector
            },
          ),
        ),
      ]),
    );
  }

  Widget _chip(String label, String value, Color color) => Expanded(
    child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
      decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8)),
      child: Column(children: [
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 9)),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
      ])),
  );

  Widget _empty() => Center(
    child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('😔', style: TextStyle(fontSize: 60)),
      const SizedBox(height: 16),
      const Text('No Colleges Found', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
      const SizedBox(height: 10),
      Text('${widget.percentage}% in ${widget.category} / ${widget.capRound} — no cutoff matched for ${widget.district}.\n\nTry: All Districts, different CAP Round, or another category.',
          textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 13, height: 1.6)),
      const SizedBox(height: 20),
      ElevatedButton.icon(
        onPressed: () => Navigator.pop(context),
        icon: const Icon(Icons.arrow_back),
        label: const Text('Go Back'),
        style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
      ),
    ])),
  );
}
