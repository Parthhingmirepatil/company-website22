import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import 'prediction_screen.dart';
import 'diploma_prediction_screen.dart';
import 'student_profile_screen.dart';
import 'developer_screen.dart';
import 'admission_info_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      appBar: AppBar(
        title: const Text('DSE College Finder', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_rounded),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const StudentProfileScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () => _confirmLogout(context, auth),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.school_rounded, color: Colors.white, size: 36),
                  const SizedBox(height: 10),
                  Text('Hello, ${auth.loggedInUser} 👋',
                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  const Text('Find eligible colleges for DSE B.Tech or Diploma Polytechnic admission',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Stats row
            Row(
              children: [
                _StatCard(icon: Icons.location_city, label: 'Districts', value: '33', color: const Color(0xFF1565C0)),
                const SizedBox(width: 12),
                _StatCard(icon: Icons.account_balance, label: 'Colleges', value: '333', color: const Color(0xFF00796B)),
                const SizedBox(width: 12),
                _StatCard(icon: Icons.engineering, label: 'Branches', value: '80', color: const Color(0xFF6A1B9A)),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
            const SizedBox(height: 12),
            // DSE B.Tech Predict button
            _ActionCard(
              icon: Icons.school_rounded,
              title: 'DSE – B.Tech Admission',
              subtitle: 'Direct 2nd year B.Tech via Diploma | CAP 1–3 cutoffs',
              color: const Color(0xFF1A237E),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PredictionScreen())),
            ),
            const SizedBox(height: 12),
            // Diploma Admission button
            _ActionCard(
              icon: Icons.menu_book_rounded,
              title: 'Diploma – Polytechnic Admission',
              subtitle: 'Post SSC Diploma in Engineering | CAP 1–4 cutoffs',
              color: const Color(0xFF00695C),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DiplomaPredictionScreen())),
            ),
            const SizedBox(height: 12),
            _ActionCard(
              icon: Icons.info_outline_rounded,
              title: 'About Admissions',
              subtitle: 'DTE Maharashtra 2025-26 CAP round cutoff data · 1664 entries across 392 polytechnics',
              color: const Color(0xFF5E35B1),
              onTap: () => _showAbout(context),
            ),
            const SizedBox(height: 12),
            _ActionCard(
              icon: Icons.assignment_rounded,
              title: 'Admission Information',
              subtitle: 'Required documents · Scholarships · Eligibility by admission type',
              color: const Color(0xFFE65100),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdmissionInfoScreen())),
            ),
            const SizedBox(height: 12),
            // Meet the Developer card
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DeveloperScreen()),
              ),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF0D47A1), Color(0xFF1565C0)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: const Color(0xFF1565C0).withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Row(children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.developer_mode_rounded, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Meet the Developer', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
                    SizedBox(height: 2),
                    Text('Contact · WhatsApp · Call · About', style: TextStyle(fontSize: 12, color: Colors.white70)),
                  ])),
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), shape: BoxShape.circle),
                    child: const Icon(Icons.arrow_forward_ios_rounded, size: 13, color: Colors.white),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 24),
            // Category reference
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFE8EAF6),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF9FA8DA)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.category_outlined, size: 16, color: Color(0xFF1A237E)),
                    SizedBox(width: 6),
                    Text('Category Reference', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1A237E), fontSize: 13)),
                  ]),
                  const SizedBox(height: 10),
                  ...const [
                    'OPEN – General / Open Category',
                    'SC – Scheduled Caste',
                    'ST – Scheduled Tribe',
                    'VJNT – Vimukta Jati & Nomadic Tribes',
                    'SBC – Special Backward Class',
                    'OBC – Other Backward Class',
                    'EWS – Economically Weaker Section',
                  ].map((t) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text('• $t', style: const TextStyle(fontSize: 12, color: Colors.black87)),
                  )),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () => _confirmLogout(context, auth),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red.shade700,
                  side: BorderSide(color: Colors.red.shade300),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.logout),
                label: const Text('Logout', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _confirmLogout(BuildContext context, AuthService auth) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () { Navigator.pop(context); auth.logout(); },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('About Admissions'),
        content: const Text(
          '🎓 DSE – Direct Second Year Engineering\n'
          'Diploma holders join B.Tech 2nd year directly. Uses CAP Round 1–3 cutoffs.\n\n'
          '🏫 Diploma – Post SSC Polytechnic\n'
          'Students after SSC (10th) can apply for 3-year Diploma in Engineering. Uses CAP Round 1–4 cutoffs.\n\n'
          'Data source: DTE Maharashtra 2025-26. Always verify on the official DTE portal.',
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color color;
  const _StatCard({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 8, offset: const Offset(0, 3))]),
        child: Column(children: [
          Icon(icon, color: color, size: 26),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: color)),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
        ]),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;
  const _ActionCard({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 8, offset: const Offset(0, 4))]),
        child: Row(children: [
          Container(padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 26)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ])),
          Icon(Icons.arrow_forward_ios, size: 14, color: color),
        ]),
      ),
    );
  }
}
