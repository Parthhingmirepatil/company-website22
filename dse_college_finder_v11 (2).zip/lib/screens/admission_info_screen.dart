import 'package:flutter/material.dart';

enum AdmissionType { diploma, dse }

// ─── DATA MODELS ─────────────────────────────────────────────────────────────

class _DocItem {
  final String name;
  final String purpose;
  final String whereToGet;
  final String? note;
  final IconData icon;
  const _DocItem({
    required this.name,
    required this.purpose,
    required this.whereToGet,
    this.note,
    required this.icon,
  });
}

class _ScholarshipItem {
  final String name;
  final String category;
  final String eligibility;
  final List<String> benefits;
  final List<String> requiredDocs;
  final String howToApply;
  final String portal;
  final String deadline;
  final Color color;
  final IconData icon;
  const _ScholarshipItem({
    required this.name,
    required this.category,
    required this.eligibility,
    required this.benefits,
    required this.requiredDocs,
    required this.howToApply,
    required this.portal,
    required this.deadline,
    required this.color,
    required this.icon,
  });
}

// ─── DIPLOMA DOCUMENTS ───────────────────────────────────────────────────────

const _diplomaDocs = [
  _DocItem(
    name: '10th SSC Marksheet',
    purpose: 'Proof of academic qualification for Diploma admission eligibility.',
    whereToGet: 'Issued by Maharashtra State Board (MSBSHSE) after SSC exams. Contact your school or download from msbshse.co.in.',
    note: 'Keep both original and 2 attested photocopies.',
    icon: Icons.description_rounded,
  ),
  _DocItem(
    name: 'School Leaving Certificate (LC)',
    purpose: 'Official record of your date of birth, religion, caste, and last attended school.',
    whereToGet: 'Collect from the Headmaster/Principal of your SSC school. Usually issued within 7 days of request.',
    note: 'Must bear the school stamp and principal signature.',
    icon: Icons.school_rounded,
  ),
  _DocItem(
    name: 'SSC Passing Certificate',
    purpose: 'Confirms that you have passed the SSC (10th) examination.',
    whereToGet: 'Issued by MSBSHSE along with the marksheet. If lost, apply for duplicate at the Board office.',
    icon: Icons.verified_rounded,
  ),
  _DocItem(
    name: 'Domicile Certificate (Maharashtra)',
    purpose: 'Proves 15-year residency in Maharashtra, required for state quota seats.',
    whereToGet: 'Apply at your local Tehsildar / Sub-Divisional Magistrate office. Requires Aadhaar, ration card, and utility bills as proof.',
    note: 'Processing takes 15-30 days. Apply early!',
    icon: Icons.home_work_rounded,
  ),
  _DocItem(
    name: 'Aadhaar Card',
    purpose: 'Mandatory identity and address proof for all government schemes and admissions.',
    whereToGet: 'Issued by UIDAI. If not available, visit nearest Aadhaar enrollment centre or apply on uidai.gov.in.',
    note: 'Carry original + 2 self-attested photocopies.',
    icon: Icons.badge_rounded,
  ),
  _DocItem(
    name: 'Caste Certificate (SC/ST/OBC/VJNT/SBC)',
    purpose: 'Required to claim reserved category seats and category-based scholarships.',
    whereToGet: 'Apply at Tehsildar / Sub-Divisional Officer (SDO) office with LC, ration card, and parent caste proof.',
    note: 'Only applicable if you belong to a reserved category.',
    icon: Icons.diversity_3_rounded,
  ),
  _DocItem(
    name: 'Non-Creamy Layer Certificate (OBC/VJNT/SBC)',
    purpose: 'Proves that family income is within the Non-Creamy Layer limit (below 8 lakh/year) for OBC reservation benefits.',
    whereToGet: 'Issued by Tehsildar office. Valid for 1 year only — ensure it is current.',
    note: 'Not required for SC/ST students.',
    icon: Icons.layers_rounded,
  ),
  _DocItem(
    name: 'Income Certificate (Parent)',
    purpose: 'Required for income-based scholarships and fee concessions.',
    whereToGet: 'Issued by Tehsildar. Bring salary slips (govt. employee) or Form 16 / income declaration (private/self-employed).',
    note: 'Valid for the current financial year only.',
    icon: Icons.attach_money_rounded,
  ),
  _DocItem(
    name: 'Passport Size Photos',
    purpose: 'Required for all admission forms, scholarship applications, and ID cards.',
    whereToGet: 'Get from any photo studio. White or light-blue background preferred.',
    note: 'Carry at least 8-10 copies in standard passport size (3.5 x 4.5 cm).',
    icon: Icons.photo_camera_rounded,
  ),
  _DocItem(
    name: 'CAP Allotment Letter',
    purpose: 'Official document from DTE Maharashtra confirming your allotted college and branch.',
    whereToGet: 'Download after CAP Round results from the DTE Maharashtra portal: dtemaharashtra.gov.in',
    note: 'Obtained after CAP admission process is complete.',
    icon: Icons.assignment_turned_in_rounded,
  ),
];

// ─── DSE DOCUMENTS ───────────────────────────────────────────────────────────

const _dseDocs = [
  _DocItem(
    name: 'Diploma Marksheet (All Semesters)',
    purpose: 'Academic eligibility proof showing semester-wise performance for DSE admission.',
    whereToGet: 'Issued by MSBTE. Download from msbte.org.in or collect from your polytechnic examination section.',
    note: 'All 6 semester marksheets required (or available semesters if final result is awaited).',
    icon: Icons.menu_book_rounded,
  ),
  _DocItem(
    name: 'Diploma Provisional Certificate',
    purpose: 'Acts as proof of completing the Diploma program before the final certificate is issued.',
    whereToGet: 'Issued by your polytechnic college examination section after final semester results.',
    note: 'If final certificate is available, use that instead.',
    icon: Icons.workspace_premium_rounded,
  ),
  _DocItem(
    name: 'SSC (10th) Marksheet',
    purpose: 'Required to verify date of birth and basic educational background.',
    whereToGet: 'Issued by MSBSHSE. Contact your school or download from msbshse.co.in.',
    icon: Icons.description_rounded,
  ),
  _DocItem(
    name: 'School Leaving Certificate (LC)',
    purpose: 'Records personal details — DOB, nationality, caste — for college verification.',
    whereToGet: 'Collect from your SSC school Headmaster / Principal.',
    note: 'Must carry original with stamp and signature.',
    icon: Icons.school_rounded,
  ),
  _DocItem(
    name: 'Migration Certificate',
    purpose: 'Required when transferring from MSBTE board to a university under DSE admission.',
    whereToGet: 'Apply to MSBTE through your polytechnic. Takes 15-30 days. Apply before the CAP round begins.',
    note: 'Mandatory for joining a university-affiliated engineering college.',
    icon: Icons.swap_horiz_rounded,
  ),
  _DocItem(
    name: 'Domicile Certificate (Maharashtra)',
    purpose: 'Establishes Maharashtra residency for state quota eligibility.',
    whereToGet: 'Apply at Tehsildar / SDO with Aadhaar, ration card, and utility bills showing 15-year residence.',
    note: 'Processing takes 15-30 days. Apply early!',
    icon: Icons.home_work_rounded,
  ),
  _DocItem(
    name: 'Aadhaar Card',
    purpose: 'Mandatory identity proof for all government admissions and scholarship portals.',
    whereToGet: 'UIDAI-issued. Apply or update at uidai.gov.in or nearest enrollment centre.',
    note: 'Carry original + 2 self-attested copies.',
    icon: Icons.badge_rounded,
  ),
  _DocItem(
    name: 'Caste Certificate (if applicable)',
    purpose: 'Required to claim reserved category seats in DSE B.Tech admission.',
    whereToGet: 'Issued by Tehsildar / SDO. Required documents: LC, ration card, parent caste affidavit.',
    note: 'Only for SC/ST/OBC/VJNT/SBC students.',
    icon: Icons.diversity_3_rounded,
  ),
  _DocItem(
    name: 'Non-Creamy Layer Certificate',
    purpose: 'Confirms family income is below 8 lakh/year to avail OBC/VJNT/SBC reservation.',
    whereToGet: 'Issued by Tehsildar with income proof. Valid for 1 year — ensure it is not expired.',
    icon: Icons.layers_rounded,
  ),
  _DocItem(
    name: 'Income Certificate',
    purpose: 'Needed for income-based scholarships like EBC, Pragati, and fee waivers.',
    whereToGet: 'Issued by Tehsildar. Bring salary slip, Form 16, or income declaration affidavit.',
    note: 'Must be for the current financial year.',
    icon: Icons.attach_money_rounded,
  ),
  _DocItem(
    name: 'CAP Allotment Letter',
    purpose: 'Confirms your allotted B.Tech college and branch under DSE CAP rounds.',
    whereToGet: 'Download from DTE Maharashtra portal after CAP Round results: dtemaharashtra.gov.in',
    icon: Icons.assignment_turned_in_rounded,
  ),
  _DocItem(
    name: 'Passport Size Photos',
    purpose: 'Required for admission forms, identity cards, and all scholarship applications.',
    whereToGet: 'Any photo studio. White/light-blue background, standard size 3.5 x 4.5 cm.',
    note: 'Carry at least 10-12 copies.',
    icon: Icons.photo_camera_rounded,
  ),
];

// ─── DIPLOMA SCHOLARSHIPS ────────────────────────────────────────────────────

const _diplomaScholarships = [
  _ScholarshipItem(
    name: 'Post Matric Scholarship — SC/ST Students',
    category: 'SC / ST',
    eligibility: 'SC or ST students enrolled in a government-recognized Diploma course in Maharashtra. Family income must be below Rs 2.5 lakh/year for SC and no income limit for ST.',
    benefits: [
      '100% Tuition Fees reimbursed directly to college',
      'Maintenance Allowance: Rs 230-380/month (Day Scholar)',
      'Maintenance Allowance: Rs 700-1,200/month (Hosteller)',
      'Study tour charges and thesis/project charges covered',
    ],
    requiredDocs: [
      'Aadhaar Card',
      'SC/ST Caste Certificate',
      'Income Certificate (below Rs 2.5 lakh for SC)',
      'Admission Fee Receipt from college',
      'Bank Account Passbook (student own account)',
      'Bonafide Certificate from college',
    ],
    howToApply: '1. Register at mahadbt.maharashtra.gov.in\n2. Fill scholarship form under Social Justice Dept\n3. Upload scanned documents\n4. Submit form and take printout\n5. Get college verification done\n6. Amount credited directly to bank account',
    portal: 'mahadbt.maharashtra.gov.in',
    deadline: 'Usually November-December of each academic year',
    color: Color(0xFF1565C0),
    icon: Icons.star_rounded,
  ),
  _ScholarshipItem(
    name: 'Rajarshee Chhatrapati Shahu Maharaj Scholarship',
    category: 'Open / General',
    eligibility: 'Open category (non-reserved) students whose family income is below Rs 8 lakh per year. Must be admitted in a government or government-aided polytechnic.',
    benefits: [
      '50% Tuition Fee reimbursement per year',
      'Applicable for all 3 years of Diploma',
      'Fee paid directly to the college by government',
    ],
    requiredDocs: [
      'Aadhaar Card',
      'Income Certificate (below Rs 8 lakh)',
      'Admission Fee Receipt',
      'Bonafide Certificate',
      'Bank Passbook (student)',
      'Domicile Certificate',
    ],
    howToApply: '1. Visit mahadbt.maharashtra.gov.in\n2. Create new account using Aadhaar and mobile number\n3. Select Higher and Technical Education department\n4. Fill and submit the scholarship form\n5. Upload required documents\n6. Submit college verification form',
    portal: 'mahadbt.maharashtra.gov.in',
    deadline: 'October-December every academic year',
    color: Color(0xFF00695C),
    icon: Icons.military_tech_rounded,
  ),
  _ScholarshipItem(
    name: 'Dr Panjabrao Deshmukh Hostel Allowance Scheme',
    category: 'All Reserved Categories',
    eligibility: 'SC/ST/OBC/VJNT/SBC students residing in government or private recognized hostels near their polytechnic college.',
    benefits: [
      'Rs 30,000/year for Pune, Mumbai, Nagpur, Aurangabad, Nashik, Amravati',
      'Rs 20,000/year for all other districts in Maharashtra',
      'Amount deposited directly to student bank account',
    ],
    requiredDocs: [
      'Aadhaar Card',
      'Caste Certificate',
      'Hostel Allotment / Admission Proof',
      'Bonafide Certificate',
      'Bank Passbook',
      'Income Certificate',
    ],
    howToApply: '1. Apply through mahadbt.maharashtra.gov.in portal\n2. Select Social Justice and Special Assistance section\n3. Choose Hostel Allowance scheme\n4. Upload hostel allotment letter and required docs\n5. Submit form with college countersignature\n6. District Social Welfare Office verifies and disburses',
    portal: 'mahadbt.maharashtra.gov.in',
    deadline: 'September-November of academic year',
    color: Color(0xFF6A1B9A),
    icon: Icons.home_rounded,
  ),
  _ScholarshipItem(
    name: 'EBC Freeship / Fee Exemption Scheme',
    category: 'EBC (Economically Backward Class)',
    eligibility: 'Open category students with family income below Rs 1 lakh/year. Must be a Maharashtra domicile studying in a government-aided or unaided polytechnic.',
    benefits: [
      'Full Tuition Fee exemption for all 3 years',
      'Exam fee exemption',
      'No repayment required — it is a freeship, not a loan',
    ],
    requiredDocs: [
      'Aadhaar Card',
      'Income Certificate (below Rs 1 lakh)',
      'Domicile Certificate',
      'Admission Receipt',
      'Bonafide Certificate',
    ],
    howToApply: '1. Submit application to your college scholarship / accounts department\n2. College forwards to DTE Maharashtra for approval\n3. No separate online portal — managed at college level\n4. Confirm process with your college office at time of admission',
    portal: 'Through College Office / DTE Maharashtra',
    deadline: 'At time of admission each academic year',
    color: Color(0xFFE65100),
    icon: Icons.account_balance_wallet_rounded,
  ),
];

// ─── DSE SCHOLARSHIPS ────────────────────────────────────────────────────────

const _dseScholarships = [
  _ScholarshipItem(
    name: 'Post Matric Scholarship — SC Students',
    category: 'SC (Scheduled Caste)',
    eligibility: 'SC students enrolled in B.Tech / BE program via DSE. Family income below Rs 2.5 lakh/year. Must have Aadhaar-linked bank account.',
    benefits: [
      '100% Tuition Fees reimbursed to college',
      'Maintenance Allowance: Rs 550/month (Day Scholar)',
      'Maintenance Allowance: Rs 1,200/month (Hosteller)',
      'Book allowance and other academic charges covered',
    ],
    requiredDocs: [
      'SC Caste Certificate',
      'Income Certificate (below Rs 2.5 lakh)',
      'Aadhaar Card',
      'Admission / Fee Receipt',
      'Bonafide Certificate from college',
      'Bank Passbook (student own Aadhaar-linked account)',
      'Previous year marksheet',
    ],
    howToApply: '1. Register at mahadbt.maharashtra.gov.in\n2. Go to Social Justice and Special Assistance section\n3. Choose Post Matric Scholarship\n4. Fill scholarship form with all required details\n5. Upload scanned documents (max 200KB each)\n6. Get college verification done\n7. Amount credited directly to student bank account',
    portal: 'mahadbt.maharashtra.gov.in',
    deadline: 'November-January of academic year',
    color: Color(0xFF1565C0),
    icon: Icons.star_rounded,
  ),
  _ScholarshipItem(
    name: 'Tuition Fee Waiver Scheme',
    category: 'EWS / Economically Weaker Section',
    eligibility: 'Students in government engineering colleges with family income below Rs 8 lakh/year. Applicable for DSE lateral entry students too.',
    benefits: [
      '100% Tuition Fee Waiver for all 3 years of B.Tech (2nd to 4th year)',
      'Directly applied to college fee records — no payment needed',
    ],
    requiredDocs: [
      'Income Certificate (below Rs 8 lakh)',
      'Aadhaar Card',
      'Domicile Certificate',
      'EWS Certificate (if applicable)',
      'Admission Confirmation Letter',
    ],
    howToApply: '1. Apply at your college accounts / scholarship department\n2. Submit income and domicile certificate at time of admission\n3. College applies fee waiver at the institutional level\n4. No separate portal — process managed through the college',
    portal: 'Through College Accounts Department',
    deadline: 'At the time of each semester fee payment',
    color: Color(0xFF00695C),
    icon: Icons.money_off_rounded,
  ),
  _ScholarshipItem(
    name: 'EBC Scholarship Scheme',
    category: 'EBC (Economically Backward Class)',
    eligibility: 'Open category students with family income below Rs 1 lakh/year. Maharashtra domicile. Studying in recognized engineering colleges.',
    benefits: [
      '50% Tuition Fee reimbursement per year',
      'Applicable for 2nd, 3rd and 4th year B.Tech under DSE',
    ],
    requiredDocs: [
      'Income Certificate (below Rs 1 lakh)',
      'Aadhaar Card',
      'Domicile Certificate',
      'Fee Receipt',
      'Bonafide Certificate',
    ],
    howToApply: '1. Apply via mahadbt.maharashtra.gov.in\n2. Select Higher and Technical Education department\n3. Choose EBC Scholarship scheme\n4. Upload all documents and submit\n5. College verifies and forwards to DTE Maharashtra',
    portal: 'mahadbt.maharashtra.gov.in',
    deadline: 'October-December every year',
    color: Color(0xFFE65100),
    icon: Icons.account_balance_wallet_rounded,
  ),
  _ScholarshipItem(
    name: 'Pragati Scholarship for Girls (AICTE)',
    category: 'Girls / Women Students',
    eligibility: 'Girl students admitted in AICTE-approved B.Tech programs. Family income below Rs 8 lakh/year. Only one girl per family is eligible.',
    benefits: [
      'Rs 50,000 per year (up to 3 years for DSE students)',
      'Contingency allowance: Rs 20,000 for books and stationery',
      'Total benefit: up to Rs 70,000 per year',
    ],
    requiredDocs: [
      'Aadhaar Card',
      'Income Certificate (below Rs 8 lakh)',
      'AICTE-approved college proof',
      'Bank Passbook / Account details',
      'Previous year marksheet',
      'Bonafide Certificate',
      'Affidavit that no sibling is availing Pragati Scholarship',
    ],
    howToApply: '1. Visit scholarships.gov.in (National Scholarship Portal)\n2. Register with Aadhaar-linked mobile number\n3. Search for Pragati Scholarship AICTE\n4. Fill form and upload documents\n5. Submit and track status on portal',
    portal: 'scholarships.gov.in',
    deadline: 'Usually October-November. Check AICTE website for exact dates.',
    color: Color(0xFFC2185B),
    icon: Icons.female_rounded,
  ),
  _ScholarshipItem(
    name: 'Saksham Scholarship Scheme (AICTE)',
    category: 'Differently-Abled Students',
    eligibility: 'Students with 40% or more disability enrolled in AICTE-approved B.Tech programs. Family income below Rs 8 lakh/year.',
    benefits: [
      'Rs 50,000 per year (up to 3 years for DSE students)',
      'Contingency allowance: Rs 20,000 for assistive devices / books',
      'Total benefit: up to Rs 70,000 per year',
    ],
    requiredDocs: [
      'Disability Certificate (40% or above, from CMO / Civil Hospital)',
      'Aadhaar Card',
      'Income Certificate (below Rs 8 lakh)',
      'Bank Passbook',
      'Bonafide Certificate from AICTE-approved college',
      'Previous year marksheet',
    ],
    howToApply: '1. Visit scholarships.gov.in\n2. Create account and log in\n3. Search Saksham Scholarship AICTE\n4. Fill the form with disability and income details\n5. Upload all required documents\n6. Submit before deadline and track status',
    portal: 'scholarships.gov.in',
    deadline: 'October-November. Check AICTE website for exact dates.',
    color: Color(0xFF00796B),
    icon: Icons.accessibility_new_rounded,
  ),
  _ScholarshipItem(
    name: 'Post Matric Scholarship — OBC/VJNT/SBC Students',
    category: 'OBC / VJNT / SBC',
    eligibility: 'OBC/VJNT/SBC students enrolled in B.Tech courses. Must hold valid Non-Creamy Layer Certificate. Family income below Rs 8 lakh/year.',
    benefits: [
      '100% Tuition Fee covered (for government colleges)',
      'Maintenance Allowance: Rs 300-550/month (Day Scholar)',
      'Maintenance Allowance: Rs 750-1,000/month (Hosteller)',
    ],
    requiredDocs: [
      'Caste Certificate (OBC/VJNT/SBC)',
      'Non-Creamy Layer Certificate (current year)',
      'Income Certificate',
      'Aadhaar Card',
      'Fee Receipt',
      'Bonafide Certificate',
      'Bank Passbook',
    ],
    howToApply: '1. Register on mahadbt.maharashtra.gov.in\n2. Select OBC Bahujan Kalyan or appropriate department\n3. Choose Post Matric Scholarship scheme\n4. Fill form and upload docs\n5. Get college verification\n6. Amount credited to bank after district office approval',
    portal: 'mahadbt.maharashtra.gov.in',
    deadline: 'November-January of the academic year',
    color: Color(0xFF5E35B1),
    icon: Icons.groups_rounded,
  ),
];

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

class AdmissionInfoScreen extends StatefulWidget {
  const AdmissionInfoScreen({super.key});

  @override
  State<AdmissionInfoScreen> createState() => _AdmissionInfoScreenState();
}

class _AdmissionInfoScreenState extends State<AdmissionInfoScreen>
    with SingleTickerProviderStateMixin {
  AdmissionType? _selectedType;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<_DocItem> get _currentDocs =>
      _selectedType == AdmissionType.diploma ? _diplomaDocs : _dseDocs;

  List<_ScholarshipItem> get _currentScholarships =>
      _selectedType == AdmissionType.diploma
          ? _diplomaScholarships
          : _dseScholarships;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A237E),
        foregroundColor: Colors.white,
        title: const Text('Admission Information',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBanner(),
            const SizedBox(height: 20),
            _buildTypeSelector(),
            const SizedBox(height: 20),
            if (_selectedType != null) ...[
              _buildSummaryRow(),
              const SizedBox(height: 16),
              _buildTabSection(),
            ] else
              _buildPlaceholder(),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFF1A237E).withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(0, 4))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.school_rounded, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text('Admission Guide',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.bold)),
            ),
          ]),
          const SizedBox(height: 6),
          const Text(
              'Documents checklist + scholarships for Maharashtra admissions',
              style: TextStyle(color: Colors.white70, fontSize: 11)),
          const SizedBox(height: 10),
          Wrap(spacing: 6, runSpacing: 6, children: [
            _BannerChip(icon: Icons.folder_rounded, label: 'Documents'),
            _BannerChip(icon: Icons.card_giftcard_rounded, label: 'Scholarships'),
            _BannerChip(icon: Icons.how_to_reg_rounded, label: 'How to Apply'),
          ]),
        ],
      ),
    );
  }

  Widget _buildTypeSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Select Admission Type',
            style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1A237E))),
        const SizedBox(height: 10),
        _TypeTile(
          value: AdmissionType.diploma,
          selected: _selectedType,
          icon: Icons.menu_book_rounded,
          title: 'Diploma (After 10th)',
          subtitle: '3-Year Polytechnic Diploma in Engineering',
          badge: '${_diplomaDocs.length} docs  |  ${_diplomaScholarships.length} scholarships',
          color: const Color(0xFF00695C),
          onTap: (v) {
            setState(() {
              _selectedType = v;
              _tabController.index = 0;
            });
          },
        ),
        const SizedBox(height: 10),
        _TypeTile(
          value: AdmissionType.dse,
          selected: _selectedType,
          icon: Icons.engineering_rounded,
          title: 'Direct Second Year B.Tech (DSE)',
          subtitle: 'Lateral Entry to B.Tech after Diploma',
          badge: '${_dseDocs.length} docs  |  ${_dseScholarships.length} scholarships',
          color: const Color(0xFF1A237E),
          onTap: (v) {
            setState(() {
              _selectedType = v;
              _tabController.index = 0;
            });
          },
        ),
      ],
    );
  }

  Widget _buildSummaryRow() {
    final isD = _selectedType == AdmissionType.diploma;
    final color = isD ? const Color(0xFF00695C) : const Color(0xFF1A237E);
    return Row(
      children: [
        _SummaryChip(
          icon: Icons.folder_copy_rounded,
          value: '${_currentDocs.length}',
          label: 'Documents',
          color: color,
        ),
        const SizedBox(width: 10),
        _SummaryChip(
          icon: Icons.card_giftcard_rounded,
          value: '${_currentScholarships.length}',
          label: 'Scholarships',
          color: const Color(0xFFE65100),
        ),
        const SizedBox(width: 10),
        _SummaryChip(
          icon: Icons.currency_rupee_rounded,
          value: isD ? 'Rs 1.2L+' : 'Rs 1.7L+',
          label: 'Max Benefit',
          color: const Color(0xFF6A1B9A),
        ),
      ],
    );
  }

  Widget _buildTabSection() {
    final isD = _selectedType == AdmissionType.diploma;
    final color = isD ? const Color(0xFF00695C) : const Color(0xFF1A237E);

    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 2))
            ],
          ),
          child: TabBar(
            controller: _tabController,
            indicatorColor: color,
            indicatorWeight: 3,
            labelColor: color,
            unselectedLabelColor: Colors.grey,
            labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            tabs: [
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.folder_copy_rounded, size: 16),
                    SizedBox(width: 6),
                    Text('Documents'),
                  ],
                ),
              ),
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.card_giftcard_rounded, size: 16),
                    SizedBox(width: 6),
                    Text('Scholarships'),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _tabController.index == 0
            ? _buildDocumentsSection(color)
            : _buildScholarshipsSection(),
      ],
    );
  }

  Widget _buildDocumentsSection(Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: color.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.2))),
          child: Row(children: [
            Icon(Icons.info_outline_rounded, size: 15, color: color),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                  'Tap any document to see its purpose, where to get it, and important tips.',
                  style: TextStyle(fontSize: 12, color: color)),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        ...List.generate(_currentDocs.length, (i) {
          return _DocCard(doc: _currentDocs[i], index: i + 1, color: color);
        }),
      ],
    );
  }

  Widget _buildScholarshipsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: const Color(0xFFE65100).withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFE65100).withOpacity(0.2))),
          child: Row(children: [
            const Icon(Icons.info_outline_rounded, size: 15, color: Color(0xFFE65100)),
            const SizedBox(width: 8),
            const Expanded(
              child: Text(
                  'Tap any scholarship to see eligibility, benefits, required documents, and step-by-step how to apply.',
                  style: TextStyle(fontSize: 12, color: Color(0xFFE65100))),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        ..._currentScholarships.map((s) => _ScholarshipCard(scholarship: s)),
      ],
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF9FA8DA).withOpacity(0.4)),
      ),
      child: const Center(
        child: Column(children: [
          Icon(Icons.touch_app_rounded, size: 52, color: Color(0xFF9FA8DA)),
          SizedBox(height: 14),
          Text('Select an admission type above',
              style: TextStyle(
                  fontSize: 15,
                  color: Color(0xFF1A237E),
                  fontWeight: FontWeight.w600)),
          SizedBox(height: 6),
          Text(
              'Documents checklist, scholarship details\nand step-by-step apply guide will appear here.',
              style: TextStyle(fontSize: 12, color: Colors.grey, height: 1.5),
              textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}

// ─── TYPE TILE ───────────────────────────────────────────────────────────────

class _TypeTile extends StatelessWidget {
  final AdmissionType value;
  final AdmissionType? selected;
  final IconData icon;
  final String title, subtitle, badge;
  final Color color;
  final ValueChanged<AdmissionType> onTap;

  const _TypeTile({
    required this.value,
    required this.selected,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = selected == value;
    return GestureDetector(
      onTap: () => onTap(value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected ? color : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: isSelected ? color : Colors.grey.shade200, width: 2),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(isSelected ? 0.3 : 0.07),
                blurRadius: 10,
                offset: const Offset(0, 4))
          ],
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: isSelected ? Colors.white.withOpacity(0.2) : color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: isSelected ? Colors.white : color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: isSelected ? Colors.white : color)),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: TextStyle(
                      fontSize: 11,
                      color: isSelected ? Colors.white70 : Colors.grey.shade600)),
              const SizedBox(height: 5),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                    color: isSelected ? Colors.white.withOpacity(0.2) : color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20)),
                child: Text(badge,
                    style: TextStyle(
                        fontSize: 10,
                        color: isSelected ? Colors.white : color,
                        fontWeight: FontWeight.w600)),
              ),
            ]),
          ),
          Icon(
              isSelected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
              color: isSelected ? Colors.white : Colors.grey.shade400,
              size: 22),
        ]),
      ),
    );
  }
}

// ─── DOC CARD ────────────────────────────────────────────────────────────────

class _DocCard extends StatefulWidget {
  final _DocItem doc;
  final int index;
  final Color color;
  const _DocCard({required this.doc, required this.index, required this.color});

  @override
  State<_DocCard> createState() => _DocCardState();
}

class _DocCardState extends State<_DocCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final d = widget.doc;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: widget.color.withOpacity(0.07),
                  blurRadius: 8,
                  offset: const Offset(0, 2))
            ]),
        child: Column(children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                      color: widget.color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8)),
                  child: Center(
                    child: Text('${widget.index}',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: widget.color)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(d.name,
                        style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87)),
                    if (!_expanded) ...[
                      const SizedBox(height: 2),
                      Text('Tap to see purpose, where to get & tips',
                          style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                    ]
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      color: widget.color.withOpacity(0.08), shape: BoxShape.circle),
                  child: Icon(d.icon, color: widget.color, size: 14),
                ),
                const SizedBox(width: 6),
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(Icons.expand_more_rounded, color: widget.color, size: 20),
                ),
              ]),
            ),
          ),
          if (_expanded) ...[
            Divider(height: 1, color: Colors.grey.shade100),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _DetailRow(
                  icon: Icons.help_outline_rounded,
                  label: 'WHY IT IS NEEDED',
                  value: d.purpose,
                  color: widget.color,
                ),
                const SizedBox(height: 10),
                _DetailRow(
                  icon: Icons.place_rounded,
                  label: 'WHERE TO GET IT',
                  value: d.whereToGet,
                  color: const Color(0xFF00695C),
                ),
                if (d.note != null) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: Colors.amber.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.amber.shade200)),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(Icons.tips_and_updates_rounded, size: 14, color: Colors.amber.shade700),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('TIP',
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.amber.shade800)),
                          const SizedBox(height: 2),
                          Text(d.note!,
                              style: TextStyle(
                                  fontSize: 12, color: Colors.amber.shade900, height: 1.4)),
                        ]),
                      ),
                    ]),
                  ),
                ],
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color color;
  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: color.withOpacity(0.05),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: color.withOpacity(0.15))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 15, color: color),
        const SizedBox(width: 8),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label,
                style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    color: color,
                    letterSpacing: 0.5)),
            const SizedBox(height: 3),
            Text(value,
                style: const TextStyle(fontSize: 12, color: Colors.black87, height: 1.4)),
          ]),
        ),
      ]),
    );
  }
}

// ─── SCHOLARSHIP CARD ────────────────────────────────────────────────────────

class _ScholarshipCard extends StatefulWidget {
  final _ScholarshipItem scholarship;
  const _ScholarshipCard({required this.scholarship});

  @override
  State<_ScholarshipCard> createState() => _ScholarshipCardState();
}

class _ScholarshipCardState extends State<_ScholarshipCard> {
  bool _expanded = false;
  int _activeTab = 0;

  @override
  Widget build(BuildContext context) {
    final s = widget.scholarship;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                  color: s.color.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 3))
            ]),
        child: Column(children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: s.color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10)),
                  child: Icon(s.icon, color: s.color, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(s.name,
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: s.color)),
                    const SizedBox(height: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                          color: s.color.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20)),
                      child: Text(s.category,
                          style: TextStyle(
                              fontSize: 10,
                              color: s.color,
                              fontWeight: FontWeight.w600)),
                    ),
                  ]),
                ),
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(Icons.keyboard_arrow_down_rounded, color: s.color),
                ),
              ]),
            ),
          ),
          if (_expanded) ...[
            Divider(height: 1, color: Colors.grey.shade100),

            // Eligibility
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                    color: const Color(0xFFF3F4FF),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF9FA8DA).withOpacity(0.4))),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.verified_user_rounded, size: 15, color: Color(0xFF3949AB)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('ELIGIBILITY',
                          style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1A237E),
                              letterSpacing: 0.5)),
                      const SizedBox(height: 3),
                      Text(s.eligibility,
                          style: const TextStyle(fontSize: 12, color: Colors.black87, height: 1.4)),
                    ]),
                  ),
                ]),
              ),
            ),

            // Deadline
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                    color: Colors.orange.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.orange.shade200)),
                child: Row(children: [
                  Icon(Icons.calendar_today_rounded, size: 14, color: Colors.orange.shade700),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('APPLICATION DEADLINE',
                          style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: Colors.orange.shade800,
                              letterSpacing: 0.4)),
                      const SizedBox(height: 2),
                      Text(s.deadline,
                          style: TextStyle(fontSize: 12, color: Colors.orange.shade900)),
                    ]),
                  ),
                ]),
              ),
            ),

            // Sub-tabs
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
              child: Row(children: [
                _SubTab(
                    label: 'Benefits',
                    icon: Icons.redeem_rounded,
                    active: _activeTab == 0,
                    color: s.color,
                    onTap: () => setState(() => _activeTab = 0)),
                const SizedBox(width: 6),
                _SubTab(
                    label: 'Documents',
                    icon: Icons.folder_rounded,
                    active: _activeTab == 1,
                    color: s.color,
                    onTap: () => setState(() => _activeTab = 1)),
                const SizedBox(width: 6),
                _SubTab(
                    label: 'How to Apply',
                    icon: Icons.how_to_reg_rounded,
                    active: _activeTab == 2,
                    color: s.color,
                    onTap: () => setState(() => _activeTab = 2)),
              ]),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
              child: _activeTab == 0
                  ? _buildBenefits(s)
                  : _activeTab == 1
                      ? _buildRequiredDocs(s)
                      : _buildHowToApply(s),
            ),
          ],
        ]),
      ),
    );
  }

  Widget _buildBenefits(_ScholarshipItem s) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: s.benefits.map((b) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              margin: const EdgeInsets.only(top: 4),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: s.color.withOpacity(0.1), shape: BoxShape.circle),
              child: Icon(Icons.check_rounded, size: 10, color: s.color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(b,
                  style: const TextStyle(fontSize: 13, color: Colors.black87, height: 1.4)),
            ),
          ]),
        );
      }).toList(),
    );
  }

  Widget _buildRequiredDocs(_ScholarshipItem s) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(s.requiredDocs.length, (i) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(children: [
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                  color: s.color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(7)),
              child: Center(
                child: Text('${i + 1}',
                    style: TextStyle(
                        fontSize: 11, fontWeight: FontWeight.bold, color: s.color)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(s.requiredDocs[i],
                  style: const TextStyle(fontSize: 13, color: Colors.black87)),
            ),
          ]),
        );
      }),
    );
  }

  Widget _buildHowToApply(_ScholarshipItem s) {
    final steps = s.howToApply.split('\n');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
              color: s.color.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8)),
          child: Row(children: [
            Icon(Icons.language_rounded, size: 14, color: s.color),
            const SizedBox(width: 6),
            Expanded(
              child: Text('Portal: ${s.portal}',
                  style: TextStyle(
                      fontSize: 12, color: s.color, fontWeight: FontWeight.w600)),
            ),
          ]),
        ),
        const SizedBox(height: 10),
        ...steps.map((step) {
          final num = step.split('.').first.replaceAll(RegExp(r'\D'), '');
          final text = step.replaceFirst(RegExp(r'^\d+\.\s*'), '');
          return Padding(
            padding: const EdgeInsets.only(bottom: 9),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 24,
                height: 24,
                margin: const EdgeInsets.only(top: 1),
                decoration: BoxDecoration(
                    color: s.color, borderRadius: BorderRadius.circular(6)),
                child: Center(
                  child: Text(num,
                      style: const TextStyle(
                          fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(text,
                    style: const TextStyle(fontSize: 12, color: Colors.black87, height: 1.4)),
              ),
            ]),
          );
        }),
      ],
    );
  }
}

// ─── SMALL HELPERS ───────────────────────────────────────────────────────────

class _BannerChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _BannerChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(20)),
      child: Row(children: [
        Icon(icon, size: 11, color: Colors.white),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 10)),
      ]),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final IconData icon;
  final String value, label;
  final Color color;
  const _SummaryChip({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.1),
                  blurRadius: 6,
                  offset: const Offset(0, 2))
            ]),
        child: Column(children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(value,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: color)),
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
        ]),
      ),
    );
  }
}

class _SubTab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool active;
  final Color color;
  final VoidCallback onTap;
  const _SubTab({
    required this.label,
    required this.icon,
    required this.active,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
            color: active ? color : color.withOpacity(0.07),
            borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 12, color: active ? Colors.white : color),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: active ? Colors.white : color)),
        ]),
      ),
    );
  }
}
