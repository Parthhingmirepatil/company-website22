import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/diploma_predictor_service.dart';
import '../services/student_profile_service.dart';
import 'diploma_result_screen.dart';

class DiplomaPredictionScreen extends StatefulWidget {
  const DiplomaPredictionScreen({super.key});
  @override
  State<DiplomaPredictionScreen> createState() => _DiplomaPredictionScreenState();
}

class _DiplomaPredictionScreenState extends State<DiplomaPredictionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _pctCtrl = TextEditingController();

  String _district = 'All Districts';
  String _branch = 'All Branches';
  String _category = 'OPEN';
  String _capRound = 'CAP1';
  bool _isPwd = false;
  bool _loading = false;
  String _loadError = '';

  // EWS removed — no EWS data exists in diploma cutoffs
  static const List<String> _categories = ['OPEN', 'SC', 'ST', 'VJNT', 'SBC', 'OBC'];
  static const List<String> _rounds = ['CAP1', 'CAP2', 'CAP3', 'CAP4'];
  static const Color _accent = Color(0xFF00695C);
  static const Color _accentDark = Color(0xFF004D40);

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    setState(() { _loading = true; _loadError = ''; });
    await DiplomaPredictorService.loadData();
    setState(() {
      _loading = false;
      _loadError = DiplomaPredictorService.loadError;
    });
  }

  @override
  void dispose() {
    _pctCtrl.dispose();
    super.dispose();
  }

  void _predict() {
    if (!_formKey.currentState!.validate()) return;
    if (!DiplomaPredictorService.isLoaded) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data still loading, please wait...')),
      );
      return;
    }
    final pct = double.parse(_pctCtrl.text.trim());
    final results = DiplomaPredictorService.predict(
      percentage: pct,
      district: _district,
      branch: _branch,
      category: _category,
      isPwd: _isPwd,
      capRound: _capRound,
    );

    // ── Save to search history ──────────────────────────────────────────────
    context.read<StudentProfileService>().addSearch(SearchHistoryEntry(
      type: 'Diploma',
      percentage: pct,
      category: _category,
      district: _district,
      branch: _branch,
      capRound: _capRound,
      isPwd: _isPwd,
      resultsCount: results.length,
      searchedAt: DateTime.now(),
    ));

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DiplomaResultScreen(
          results: results,
          percentage: pct,
          district: _district,
          branch: _branch,
          category: _category,
          isPwd: _isPwd,
          capRound: _capRound,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: const Color(0xFFF0F9F6),
        appBar: AppBar(
          backgroundColor: _accentDark,
          title: const Text('Diploma Admission', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        body: const Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            CircularProgressIndicator(color: Color(0xFF00695C)),
            SizedBox(height: 16),
            Text('Loading diploma data...', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text('1664 polytechnic cutoff entries', style: TextStyle(color: Colors.grey, fontSize: 12)),
          ]),
        ),
      );
    }

    if (_loadError.isNotEmpty) {
      return Scaffold(
        backgroundColor: const Color(0xFFF0F9F6),
        appBar: AppBar(
          backgroundColor: _accentDark,
          title: const Text('Diploma Admission', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              const Text('Failed to load data', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(_loadError, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _initData,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
                style: ElevatedButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white),
              ),
            ]),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF0F9F6),
      appBar: AppBar(
        backgroundColor: _accentDark,
        title: const Text('Diploma Admission', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Info Banner
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF00695C), Color(0xFF00897B)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(children: [
                const Icon(Icons.school_rounded, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Post SSC Diploma Admission',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(
                    'DTE Maharashtra 2025-26  •  ${DiplomaPredictorService.loadedCount} cutoff entries loaded',
                    style: const TextStyle(color: Colors.white70, fontSize: 11),
                  ),
                ])),
              ]),
            ),
            const SizedBox(height: 22),

            _section('📊 SSC Percentage'),
            const SizedBox(height: 10),
            TextFormField(
              controller: _pctCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'SSC Percentage (%)',
                prefixIcon: const Icon(Icons.percent, color: Color(0xFF00695C)),
                hintText: 'e.g. 75.50',
                helperText: 'Most cutoffs are between 36% and 98%',
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF00695C), width: 2),
                ),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Enter your SSC percentage';
                final d = double.tryParse(v.trim());
                if (d == null || d < 0 || d > 100) return 'Enter a valid percentage (0–100)';
                return null;
              },
            ),
            const SizedBox(height: 22),

            _section('🏫 Branch Preference'),
            const SizedBox(height: 10),
            _dropdown('Select Branch', Icons.engineering_outlined, _branch,
                DiplomaPredictorService.allBranches, (v) => setState(() => _branch = v!)),
            const SizedBox(height: 22),

            _section('📍 District'),
            const SizedBox(height: 10),
            _dropdown('Select District', Icons.location_city_outlined, _district,
                DiplomaPredictorService.allDistricts, (v) => setState(() => _district = v!)),
            const SizedBox(height: 22),

            _section('🏷️ Category'),
            const SizedBox(height: 10),
            _dropdown('Select Category', Icons.category_outlined, _category,
                _categories, (v) => setState(() => _category = v!)),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: CheckboxListTile(
                value: _isPwd,
                onChanged: (v) => setState(() => _isPwd = v ?? false),
                title: const Text('PWD – Person with Disability',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                subtitle: const Text('+5% relaxation applied to cutoff',
                    style: TextStyle(fontSize: 12, color: Colors.grey)),
                secondary: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.accessibility_new, color: _accent, size: 22),
                ),
                activeColor: _accent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 22),

            _section('🔄 CAP Round'),
            const SizedBox(height: 6),
            const Text(
              'If no results found in selected round, app will automatically search other rounds.',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            Row(
              children: _rounds.map((r) {
                final sel = _capRound == r;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _capRound = r),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: sel ? _accentDark : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: sel ? _accentDark : Colors.grey.shade300),
                        boxShadow: sel
                            ? [BoxShadow(color: _accentDark.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3))]
                            : null,
                      ),
                      alignment: Alignment.center,
                      child: Text(r,
                          style: TextStyle(
                            color: sel ? Colors.white : Colors.black87,
                            fontWeight: sel ? FontWeight.bold : FontWeight.normal,
                            fontSize: 13,
                          )),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 30),

            SizedBox(
              height: 54,
              child: ElevatedButton.icon(
                onPressed: _predict,
                icon: const Icon(Icons.search_rounded, size: 22),
                label: const Text('Find Eligible Polytechnics',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accentDark,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 4,
                ),
              ),
            ),
            const SizedBox(height: 20),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFE0F2F1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF80CBC4)),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, size: 16, color: Color(0xFF00695C)),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Data: DTE Maharashtra 2025-26 Post SSC Diploma CAP Rounds I–IV.\n'
                      'Categories available: OPEN, SC, ST, OBC, SBC, VJNT.\n'
                      'Results are indicative — always verify on the official DTE portal.',
                      style: TextStyle(fontSize: 11, color: Color(0xFF004D40), height: 1.5),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _section(String label) => Text(label,
      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF004D40)));

  Widget _dropdown(String label, IconData icon, String value, List<String> items,
      void Function(String?) onChanged) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: _accent),
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
        ),
        items: items
            .map((e) => DropdownMenuItem(value: e, child: Text(e, overflow: TextOverflow.ellipsis)))
            .toList(),
        onChanged: onChanged,
        isExpanded: true,
        dropdownColor: Colors.white,
      ),
    );
  }
}
