import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/predictor_service.dart';
import '../services/student_profile_service.dart';
import '../models/college_model.dart';
import 'college_detail_screen.dart';

class PredictionScreen extends StatefulWidget {
  const PredictionScreen({super.key});
  @override
  State<PredictionScreen> createState() => _PredictionScreenState();
}

class _PredictionScreenState extends State<PredictionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _pctCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  String _district = 'All Districts';
  String _branch = 'All Branches';
  String _category = 'OPEN';
  String _capRound = 'CAP1';
  bool _isPwd = false;
  String _sort = 'Margin';
  String _search = '';
  bool _loading = true;

  List<PredictionResult>? _results;
  bool _filtersExpanded = true;

  static const List<String> _categories = ['OPEN', 'SC', 'ST', 'VJNT', 'SBC', 'OBC', 'EWS'];
  static const List<String> _rounds = ['CAP1', 'CAP2'];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    await PredictorService.loadData();
    if (mounted) setState(() => _loading = false);
  }

  @override
  void dispose() {
    _pctCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _predict() {
    if (!_formKey.currentState!.validate()) return;
    final pct = double.parse(_pctCtrl.text.trim());
    final results = PredictorService.predict(
      percentage: pct,
      district: _district,
      category: _category,
      isPwd: _isPwd,
      capRound: _capRound,
      branch: _branch,
    );
    setState(() {
      _results = results;
      _filtersExpanded = false;
    });

    // ── Save to search history ──────────────────────────────────────────────
    context.read<StudentProfileService>().addSearch(SearchHistoryEntry(
      type: 'DSE',
      percentage: pct,
      category: _category,
      district: _district,
      branch: _branch,
      capRound: _capRound,
      isPwd: _isPwd,
      resultsCount: results.length,
      searchedAt: DateTime.now(),
    ));

    Future.delayed(const Duration(milliseconds: 300), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeOut,
        );
      }
    });
  }

  List<PredictionResult> get _filtered {
    if (_results == null) return [];
    List<PredictionResult> list = _results!.toList();
    if (_search.isNotEmpty) {
      final q = _search.toLowerCase();
      list = list.where((r) =>
        r.college.collegeName.toLowerCase().contains(q) ||
        r.college.branch.toLowerCase().contains(q) ||
        r.college.district.toLowerCase().contains(q)).toList();
    }
    switch (_sort) {
      case 'Margin': list.sort((a, b) => a.margin.compareTo(b.margin)); break;
      case 'Cutoff': list.sort((a, b) => b.cutoff.compareTo(a.cutoff)); break;
      case 'College': list.sort((a, b) => a.college.collegeName.compareTo(b.college.collegeName)); break;
      case 'District': list.sort((a, b) => a.college.district.compareTo(b.college.district)); break;
    }
    return list;
  }

  Color _chanceColor(double margin) {
    if (margin <= 1) return const Color(0xFFD32F2F);
    if (margin <= 3) return const Color(0xFFE65100);
    if (margin <= 7) return const Color(0xFF2E7D32);
    return const Color(0xFF1565C0);
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    if (_loading) {
      return Scaffold(
        backgroundColor: const Color(0xFFF0F4FF),
        appBar: AppBar(title: const Text('Predict My College', style: TextStyle(fontWeight: FontWeight.bold))),
        body: const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text('Loading DSE data...', style: TextStyle(color: Colors.grey)),
        ])),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      appBar: AppBar(
        title: const Text('Predict My College', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          if (_results != null)
            Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)),
              child: Center(child: Text('${_results!.length} found',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
            ),
        ],
      ),
      body: CustomScrollView(
        controller: _scrollCtrl,
        slivers: [
          // FILTER PANEL
          SliverToBoxAdapter(
            child: Container(
              color: Colors.white,
              child: Column(children: [
                InkWell(
                  onTap: () => setState(() => _filtersExpanded = !_filtersExpanded),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(children: [
                      const Icon(Icons.tune_rounded, color: Color(0xFF1A237E), size: 20),
                      const SizedBox(width: 8),
                      const Text('Search Filters',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF1A237E))),
                      const Spacer(),
                      if (_results != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                              color: const Color(0xFF1A237E).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10)),
                          child: Text(
                            '${_pctCtrl.text}% · $_category · $_capRound',
                            style: const TextStyle(fontSize: 11, color: Color(0xFF1A237E)),
                          ),
                        ),
                      const SizedBox(width: 6),
                      Icon(_filtersExpanded ? Icons.expand_less : Icons.expand_more,
                          color: const Color(0xFF1A237E)),
                    ]),
                  ),
                ),
                if (_filtersExpanded)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Form(
                      key: _formKey,
                      child: Column(children: [
                        TextFormField(
                          controller: _pctCtrl,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                            labelText: 'Your Diploma Percentage (%)',
                            prefixIcon: const Icon(Icons.percent, color: Color(0xFF3949AB)),
                            hintText: 'e.g. 75.50',
                            filled: true,
                            fillColor: const Color(0xFFF5F7FF),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade200)),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF3949AB))),
                          ),
                          validator: (v) {
                            if (v == null || v.trim().isEmpty) return 'Enter your percentage';
                            final d = double.tryParse(v.trim());
                            if (d == null || d < 0 || d > 100) return 'Enter a valid percentage (0-100)';
                            return null;
                          },
                        ),
                        const SizedBox(height: 12),
                        // ── BRANCH SELECTION (NEW) ──
                        _dropdown('Select Branch (Optional)', Icons.engineering_outlined, _branch,
                            PredictorService.allBranches, (v) => setState(() => _branch = v!)),
                        const SizedBox(height: 12),
                        _dropdown('Select District', Icons.location_city_outlined, _district,
                            PredictorService.allDistricts, (v) => setState(() => _district = v!)),
                        const SizedBox(height: 12),
                        _dropdown('Select Category', Icons.category_outlined, _category,
                            _categories, (v) => setState(() => _category = v!)),
                        const SizedBox(height: 12),
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5F7FF),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: CheckboxListTile(
                            value: _isPwd,
                            onChanged: (v) => setState(() => _isPwd = v ?? false),
                            title: const Text('PWD – Person with Disability',
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                            subtitle: const Text('+5% relaxation applied',
                                style: TextStyle(fontSize: 11, color: Colors.grey)),
                            secondary: const Icon(Icons.accessibility_new, color: Color(0xFF1A237E), size: 22),
                            activeColor: const Color(0xFF1A237E),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: _rounds.map((r) {
                            final sel = _capRound == r;
                            return Expanded(
                              child: GestureDetector(
                                onTap: () => setState(() => _capRound = r),
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  margin: const EdgeInsets.symmetric(horizontal: 4),
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                    color: sel ? const Color(0xFF1A237E) : const Color(0xFFF5F7FF),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: sel ? const Color(0xFF1A237E) : Colors.grey.shade300),
                                    boxShadow: sel
                                        ? [BoxShadow(color: const Color(0xFF1A237E).withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3))]
                                        : null,
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(r,
                                      style: TextStyle(
                                        color: sel ? Colors.white : Colors.black87,
                                        fontWeight: sel ? FontWeight.bold : FontWeight.normal,
                                        fontSize: 13,
                                      )),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton.icon(
                            onPressed: _predict,
                            icon: const Icon(Icons.search_rounded, size: 20),
                            label: const Text('Find Eligible Colleges',
                                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                            style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              elevation: 3,
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ),
                const Divider(height: 1),
              ]),
            ),
          ),

          // RESULTS
          if (_results != null) ...[
            SliverToBoxAdapter(
              child: Container(
                color: const Color(0xFF1A237E),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  _chip('Eligible', '${_results!.length}', Colors.greenAccent),
                  const SizedBox(width: 8),
                  _chip('District', _district.length > 12 ? '${_district.substring(0, 11)}…' : _district, Colors.lightBlueAccent),
                  const SizedBox(width: 8),
                  _chip('Your %', '${double.tryParse(_pctCtrl.text)?.toStringAsFixed(1) ?? _pctCtrl.text}%', Colors.yellowAccent),
                ]),
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                child: Column(children: [
                  TextField(
                    decoration: InputDecoration(
                      hintText: 'Search college, branch or district...',
                      prefixIcon: const Icon(Icons.search, size: 20),
                      filled: true,
                      fillColor: const Color(0xFFF5F5F5),
                      contentPadding: const EdgeInsets.symmetric(vertical: 8),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                    ),
                    onChanged: (v) => setState(() => _search = v),
                  ),
                  const SizedBox(height: 8),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      const Text('Sort: ', style: TextStyle(fontSize: 12, color: Colors.grey)),
                      ...['Margin', 'Cutoff', 'College', 'District'].map((s) => GestureDetector(
                        onTap: () => setState(() => _sort = s),
                        child: Container(
                          margin: const EdgeInsets.only(left: 6),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            color: _sort == s ? const Color(0xFF1A237E) : const Color(0xFFF0F0F0),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(s, style: TextStyle(
                            fontSize: 12,
                            color: _sort == s ? Colors.white : Colors.black87,
                            fontWeight: _sort == s ? FontWeight.bold : FontWeight.normal,
                          )),
                        ),
                      )),
                    ]),
                  ),
                ]),
              ),
            ),
            if (filtered.isEmpty)
              SliverToBoxAdapter(child: _empty())
            else
              SliverPadding(
                padding: const EdgeInsets.all(14),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) {
                      final r = filtered[i];
                      final c = _chanceColor(r.margin);
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => CollegeDetailScreen(
                            college: r.college,
                            userPercentage: r.userPercentage,
                            userCategory: r.category,
                          ),
                        )),
                        child: Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        elevation: 2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border(left: BorderSide(color: c, width: 4)),
                          ),
                          padding: const EdgeInsets.all(14),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Container(
                                width: 32, height: 32,
                                decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.1), shape: BoxShape.circle),
                                alignment: Alignment.center,
                                child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1A237E), fontSize: 12)),
                              ),
                              const SizedBox(width: 10),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(r.college.collegeName,
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF1A237E))),
                                const SizedBox(height: 3),
                                Row(children: [
                                  const Icon(Icons.location_on_outlined, size: 12, color: Colors.grey),
                                  const SizedBox(width: 2),
                                  Text(r.college.district, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                                ]),
                              ])),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
                                child: Text(r.chanceLabel, style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 10)),
                              ),
                            ]),
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(color: const Color(0xFFE8EAF6), borderRadius: BorderRadius.circular(8)),
                              child: Row(mainAxisSize: MainAxisSize.min, children: [
                                const Icon(Icons.engineering_outlined, size: 13, color: Color(0xFF3949AB)),
                                const SizedBox(width: 4),
                                Flexible(child: Text(r.college.branch,
                                    style: const TextStyle(fontSize: 12, color: Color(0xFF3949AB), fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis)),
                              ]),
                            ),
                            const SizedBox(height: 10),
                            const Divider(height: 1),
                            const SizedBox(height: 10),
                            Row(children: [
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                  Text('Cutoff (${r.category}): ${r.cutoff.toStringAsFixed(2)}%',
                                      style: const TextStyle(fontSize: 11, color: Colors.grey)),
                                  Text('You: ${r.userPercentage.toStringAsFixed(2)}%',
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
                                ]),
                                const SizedBox(height: 4),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: (r.cutoff / 100).clamp(0.0, 1.0),
                                    backgroundColor: Colors.grey.shade200,
                                    valueColor: AlwaysStoppedAnimation<Color>(c),
                                    minHeight: 6,
                                  ),
                                ),
                              ])),
                              const SizedBox(width: 12),
                              Column(children: [
                                Text('+${r.margin.toStringAsFixed(1)}%',
                                    style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 14)),
                                Text('margin', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
                              ]),
                            ]),
                            const SizedBox(height: 6),
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                              Text('${r.capRound} Cutoff', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.08), borderRadius: BorderRadius.circular(4)),
                                child: Text(r.category, style: const TextStyle(fontSize: 10, color: Color(0xFF1A237E), fontWeight: FontWeight.bold)),
                              ),
                            ]),
                            const SizedBox(height: 8),
                            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                              const Icon(Icons.info_outline, size: 11, color: Colors.blueGrey),
                              const SizedBox(width: 3),
                              Text('Tap for full cutoff details',
                                style: TextStyle(fontSize: 10, color: Colors.blueGrey.shade400, fontStyle: FontStyle.italic)),
                            ]),
                          ]),
                        ),
                      ), // Card
                      ); // GestureDetector
                    },
                    childCount: filtered.length,
                  ),
                ),
              ),
          ],

          // EMPTY STATE (before first search)
          if (_results == null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(children: [
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.07), shape: BoxShape.circle),
                    child: const Icon(Icons.search_rounded, size: 52, color: Color(0xFF1A237E)),
                  ),
                  const SizedBox(height: 20),
                  const Text('Fill the filters above',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
                  const SizedBox(height: 8),
                  const Text('Enter your percentage, select district & category,\nthen tap "Find Eligible Colleges"',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.6)),
                  const SizedBox(height: 24),
                  Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
                    _infoBadge('🏛️ 333 Colleges'),
                    _infoBadge('🔬 80 Branches'),
                    _infoBadge('📍 33 Districts'),
                    _infoBadge('📋 1477 Entries'),
                    _infoBadge('📅 2024-25 Data'),
                  ]),
                ]),
              ),
            ),
        ],
      ),
    );
  }

  Widget _chip(String label, String value, Color color) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
      decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8)),
      child: Column(children: [
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 9)),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
      ]),
    ),
  );

  Widget _infoBadge(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.08), borderRadius: BorderRadius.circular(20)),
    child: Text(text, style: const TextStyle(fontSize: 12, color: Color(0xFF1A237E), fontWeight: FontWeight.w500)),
  );

  Widget _dropdown(String label, IconData icon, String value, List<String> items, void Function(String?) onChanged) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF5F7FF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: const Color(0xFF3949AB)),
          border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none,
        ),
        items: items.map((e) => DropdownMenuItem(value: e, child: Text(e, overflow: TextOverflow.ellipsis))).toList(),
        onChanged: onChanged,
        isExpanded: true,
        dropdownColor: Colors.white,
      ),
    );
  }

  Widget _empty() => Padding(
    padding: const EdgeInsets.all(32),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('😔', style: TextStyle(fontSize: 56)),
      const SizedBox(height: 14),
      const Text('No Colleges Found',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
      const SizedBox(height: 10),
      Text(
        '${_pctCtrl.text}% in $_category / $_capRound — no match for $_district${_branch != 'All Branches' ? ' / $_branch' : ''}.\n\nTry: All Districts, All Branches, different CAP Round, or another category.',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.grey, fontSize: 13, height: 1.6),
      ),
      const SizedBox(height: 20),
      ElevatedButton.icon(
        onPressed: () => setState(() { _filtersExpanded = true; _results = null; }),
        icon: const Icon(Icons.tune),
        label: const Text('Adjust Filters'),
        style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
      ),
    ]),
  );
}
