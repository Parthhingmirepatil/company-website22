import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/college_model.dart';
import '../services/college_info_service.dart';

class CollegeDetailScreen extends StatefulWidget {
  final CollegeModel college;
  final double userPercentage;
  final String userCategory;

  const CollegeDetailScreen({
    super.key,
    required this.college,
    required this.userPercentage,
    required this.userCategory,
  });

  @override
  State<CollegeDetailScreen> createState() => _CollegeDetailScreenState();
}

class _CollegeDetailScreenState extends State<CollegeDetailScreen>
    with SingleTickerProviderStateMixin {
  static const List<String> _catOrder = [
    'OPEN','OBC','SC','ST','SBC','VJNT','EWS','OPEN_LADIES','SC_LADIES','OBC_LADIES','PWD'
  ];

  late TabController _tabCtrl;
  CollegeInfo? _info;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    final rounds = widget.college.cutoffs.keys.toList()..sort();
    _tabCtrl = TabController(length: rounds.length + 1, vsync: this);
    _loadInfo();
  }

  Future<void> _loadInfo() async {
    final svc = CollegeInfoService();
    await svc.load();
    if (mounted) setState(() { _info = svc.findInfo(widget.college.collegeName); _loaded = true; });
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  Color _color(double c) {
    final m = widget.userPercentage - c;
    if (m >= 10) return const Color(0xFF1565C0);
    if (m >= 5)  return const Color(0xFF2E7D32);
    if (m >= 2)  return const Color(0xFFE65100);
    if (m >= 0)  return const Color(0xFFD32F2F);
    return Colors.grey.shade400;
  }

  String _label(double c) {
    final m = widget.userPercentage - c;
    if (m >= 10) return 'Strong';
    if (m >= 5)  return 'Good';
    if (m >= 2)  return 'Moderate';
    if (m >= 0)  return 'Tight';
    return 'Below';
  }

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open link'), backgroundColor: Colors.red));
    }
  }

  void _copy(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$label copied!'), behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 1)));
  }

  @override
  Widget build(BuildContext context) {
    final rounds = widget.college.cutoffs.keys.toList()..sort();
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            expandedHeight: 170,
            pinned: true,
            backgroundColor: const Color(0xFF1A237E),
            foregroundColor: Colors.white,
            title: const Text('College Details', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            flexibleSpace: FlexibleSpaceBar(background: _header()),
            bottom: TabBar(
              controller: _tabCtrl,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicatorColor: Colors.white,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white60,
              labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              dividerColor: Colors.transparent,
              tabs: [const Tab(text: 'Info'), ...rounds.map((r) => Tab(text: r))],
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabCtrl,
          children: [_infoTab(), ...rounds.map((r) => _cutoffTab(r))],
        ),
      ),
    );
  }

  Widget _header() => Container(
    decoration: const BoxDecoration(gradient: LinearGradient(
      colors: [Color(0xFF1A237E), Color(0xFF3949AB)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
    padding: const EdgeInsets.fromLTRB(16, 56, 16, 6),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.account_balance, color: Colors.white, size: 22)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.college.collegeName, style: const TextStyle(color: Colors.white,
              fontWeight: FontWeight.bold, fontSize: 12, height: 1.3), maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 3),
          Row(children: [
            const Icon(Icons.location_on, size: 11, color: Colors.white70),
            const SizedBox(width: 3),
            Text(widget.college.district, style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ]),
        ])),
      ]),
      const SizedBox(height: 8),
      Wrap(spacing: 5, runSpacing: 4, children: [
        _pill(Icons.engineering, widget.college.branch),
        _pill(Icons.person, '${widget.userPercentage.toStringAsFixed(1)}%'),
        _pill(Icons.category, widget.userCategory),
      ]),
    ]),
  );

  Widget _pill(IconData icon, String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.18), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 11, color: Colors.white70), const SizedBox(width: 4),
      Text(text, style: const TextStyle(color: Colors.white, fontSize: 11), overflow: TextOverflow.ellipsis),
    ]),
  );

  // ═══ INFO TAB ═══════════════════════════════════════════════════════════════
  Widget _infoTab() {
    if (!_loaded) return const Center(child: CircularProgressIndicator());
    return ListView(padding: const EdgeInsets.all(14), children: [

      // Quick actions
      Row(children: [
        _actBtn(Icons.map_rounded, 'Maps', const Color(0xFF1565C0),
            _info?.mapsUrl.isNotEmpty == true ? () => _open(_info!.mapsUrl) : null),
        const SizedBox(width: 8),
        _actBtn(Icons.call_rounded, 'Call', const Color(0xFF2E7D32),
            _info?.phone.isNotEmpty == true ? () => _open('tel:${_info!.phone}') : null),
        const SizedBox(width: 8),
        _actBtn(Icons.email_rounded, 'Email', const Color(0xFFE65100),
            _info?.email.isNotEmpty == true ? () => _open('mailto:${_info!.email}') : null),
        if (_info?.website.isNotEmpty == true) ...[
          const SizedBox(width: 8),
          _actBtn(Icons.language_rounded, 'Website', const Color(0xFF6A1B9A),
              () => _open(_info!.website)),
        ],
      ]),
      const SizedBox(height: 14),

      // College Info
      _card('College Information', Icons.info_outline_rounded, Column(children: [
        _row2(Icons.account_balance, 'Name', widget.college.collegeName, copy: true),
        _div(),
        _row2(Icons.location_city_rounded, 'District', widget.college.district),
        if (_info?.address.isNotEmpty == true) ...[_div(), _row2(Icons.location_on_rounded, 'Address', _info!.address)],
        if (_info?.established.isNotEmpty == true) ...[_div(), _row2(Icons.calendar_today_rounded, 'Established', _info!.established)],
        if (_info?.affiliation.isNotEmpty == true) ...[_div(), _row2(Icons.school_rounded, 'Affiliated To', _info!.affiliation)],
        _div(),
        _row2(Icons.badge_rounded, 'College Type', _colType()),
      ])),
      const SizedBox(height: 12),

      // Contact
      _card('Contact Details', Icons.contact_phone_rounded, Column(children: [
        _cTile(Icons.call_rounded, const Color(0xFF2E7D32), 'Phone',
            _info?.phone.isNotEmpty == true ? _info!.phone : 'Not Available',
            onTap: _info?.phone.isNotEmpty == true ? () => _open('tel:${_info!.phone}') : null,
            onCopy: _info?.phone.isNotEmpty == true ? () => _copy(_info!.phone, 'Phone') : null),
        _div(),
        _cTile(Icons.email_rounded, const Color(0xFFE65100), 'Email',
            _info?.email.isNotEmpty == true ? _info!.email : 'Not Available',
            onTap: _info?.email.isNotEmpty == true ? () => _open('mailto:${_info!.email}') : null,
            onCopy: _info?.email.isNotEmpty == true ? () => _copy(_info!.email, 'Email') : null),
        if (_info?.website.isNotEmpty == true) ...[
          _div(),
          _cTile(Icons.language_rounded, const Color(0xFF6A1B9A), 'Website', _info!.website,
              onTap: () => _open(_info!.website), onCopy: null),
        ],
        if (_info?.principal.isNotEmpty == true) ...[
          _div(),
          _cTile(Icons.person_rounded, const Color(0xFF1565C0), 'Principal / HoD', _info!.principal,
              onTap: null, onCopy: null),
        ],
      ])),
      const SizedBox(height: 12),

      // Google Maps
      _card('Location & Directions', Icons.map_rounded, Column(children: [
        // Map visual
        Container(
          height: 140, margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFE3F2FD), borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF1565C0).withOpacity(0.2))),
          child: Stack(children: [
            ClipRRect(borderRadius: BorderRadius.circular(12),
              child: CustomPaint(size: const Size(double.infinity, 140), painter: _MapBg())),
            Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: const Color(0xFF1565C0),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [BoxShadow(color: const Color(0xFF1565C0).withOpacity(0.4), blurRadius: 8)]),
                child: const Icon(Icons.location_on, color: Colors.white, size: 24)),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                  boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)]),
                child: Text(widget.college.district,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1A237E)))),
            ])),
          ]),
        ),
        SizedBox(width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _info?.mapsUrl.isNotEmpty == true ? () => _open(_info!.mapsUrl) : null,
            icon: const Icon(Icons.open_in_new_rounded, size: 18),
            label: const Text('Open in Google Maps', style: TextStyle(fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          )),
        if (_info?.address.isNotEmpty == true) ...[
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.pin_drop_rounded, size: 14, color: Colors.grey),
            const SizedBox(width: 6),
            Expanded(child: Text(_info!.address, style: const TextStyle(fontSize: 12, color: Colors.grey))),
          ]),
        ],
      ])),
      const SizedBox(height: 12),

      // Branch
      _card('Branch & Course Info', Icons.engineering_rounded, Column(children: [
        _row2(Icons.engineering_rounded, 'Branch', widget.college.branch),
        _div(),
        _row2(Icons.school_outlined, 'Programme', 'B.Tech / B.E. (4 Years)'),
        _div(),
        _row2(Icons.assignment_rounded, 'Admission Type', 'Direct 2nd Year (DSE) Lateral Entry'),
        _div(),
        _row2(Icons.account_balance_rounded, 'Regulatory Body', 'DTE Maharashtra / MHTCET'),
        _div(),
        _row2(Icons.loop_rounded, 'Rounds Available', widget.college.cutoffs.keys.join(', ')),
      ])),
      const SizedBox(height: 12),

      // Eligibility
      _card('Your Eligibility', Icons.verified_rounded, Column(children: [
        ...widget.college.cutoffs.entries.map((e) {
          final round = e.key;
          final myCut = e.value[widget.userCategory];
          if (myCut == null) return const SizedBox.shrink();
          final margin = widget.userPercentage - myCut;
          final col = _color(myCut);
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: col.withOpacity(0.06), borderRadius: BorderRadius.circular(12),
              border: Border.all(color: col.withOpacity(0.3))),
            child: Row(children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(8)),
                child: Text(round, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${widget.userCategory} cutoff: ${myCut.toStringAsFixed(2)}%',
                    style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(margin >= 0 ? 'Margin: +${margin.toStringAsFixed(2)}%  ✓ Eligible'
                    : 'Short by: ${margin.abs().toStringAsFixed(2)}%  ✗ Not Eligible',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: col)),
              ])),
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: col.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                child: Text(_label(myCut), style: TextStyle(color: col, fontSize: 11, fontWeight: FontWeight.bold))),
            ]),
          );
        }),
        if (!widget.college.cutoffs.values.any((c) => c.containsKey(widget.userCategory)))
          Container(padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              const Icon(Icons.info_outline, color: Colors.grey),
              const SizedBox(width: 10),
              Expanded(child: Text('No cutoff data for ${widget.userCategory}',
                  style: const TextStyle(color: Colors.grey, fontSize: 13))),
            ])),
      ])),
      const SizedBox(height: 24),
    ]);
  }

  // ═══ CUTOFF TAB ═════════════════════════════════════════════════════════════
  Widget _cutoffTab(String round) {
    final cats = widget.college.cutoffs[round] ?? {};
    final ordered = _catOrder.where((c) => cats.containsKey(c)).toList();
    for (final c in cats.keys) { if (!ordered.contains(c)) ordered.add(c); }

    return ListView(padding: const EdgeInsets.all(14), children: [
      Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: const Color(0xFF1A237E), borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          const Icon(Icons.bar_chart_rounded, color: Colors.white70, size: 20),
          const SizedBox(width: 10),
          Text('$round — ${cats.length} categories',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
          const Spacer(),
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)),
            child: Text('Your: ${widget.userPercentage.toStringAsFixed(1)}%',
                style: const TextStyle(color: Colors.white, fontSize: 12))),
        ])),

      // Header row
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: const BoxDecoration(color: Color(0xFFE8EAF6),
          borderRadius: BorderRadius.only(topLeft: Radius.circular(14), topRight: Radius.circular(14))),
        child: const Row(children: [
          Expanded(flex: 3, child: Text('Category', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF1A237E)))),
          Expanded(flex: 2, child: Text('Cutoff %', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF1A237E)), textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text('Margin', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF1A237E)), textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text('Chance', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF1A237E)), textAlign: TextAlign.center)),
        ]),
      ),

      Container(
        decoration: BoxDecoration(color: Colors.white,
          borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(14), bottomRight: Radius.circular(14)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)]),
        child: Column(children: ordered.asMap().entries.map((e) {
          final idx = e.key; final cat = e.value;
          final cutoff = cats[cat]!;
          final margin = widget.userPercentage - cutoff;
          final col = _color(cutoff);
          final isMe = cat == widget.userCategory;
          return Container(
            decoration: BoxDecoration(
              color: isMe ? const Color(0xFFFFF8E1) : (idx.isEven ? Colors.white : const Color(0xFFFAFAFF)),
              border: isMe ? Border(left: BorderSide(color: Colors.amber.shade600, width: 4)) : null),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              Expanded(flex: 3, child: Row(children: [
                if (isMe) ...[const Icon(Icons.star_rounded, size: 13, color: Colors.amber), const SizedBox(width: 3)],
                Flexible(child: Text(cat, style: TextStyle(
                    fontWeight: isMe ? FontWeight.bold : FontWeight.w500,
                    fontSize: 12, color: isMe ? const Color(0xFF1A237E) : Colors.black87))),
              ])),
              Expanded(flex: 2, child: Text('${cutoff.toStringAsFixed(2)}%',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
              Expanded(flex: 2, child: Text(margin >= 0 ? '+${margin.toStringAsFixed(1)}%' : '${margin.toStringAsFixed(1)}%',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: col))),
              Expanded(flex: 2, child: Center(child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(color: col.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                child: Text(_label(cutoff), style: TextStyle(fontSize: 10, color: col, fontWeight: FontWeight.bold))))),
            ]),
          );
        }).toList()),
      ),
      const SizedBox(height: 14),
      // Legend
      Container(padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Legend', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF1A237E))),
          const SizedBox(height: 6),
          Wrap(spacing: 10, runSpacing: 4, children: [
            _dot(const Color(0xFF1565C0), 'Strong ≥10%'),
            _dot(const Color(0xFF2E7D32), 'Good 5–10%'),
            _dot(const Color(0xFFE65100), 'Moderate 2–5%'),
            _dot(const Color(0xFFD32F2F), 'Tight 0–2%'),
            _dot(Colors.grey, 'Below cutoff'),
          ]),
        ])),
      const SizedBox(height: 20),
    ]);
  }

  // ═══ HELPERS ════════════════════════════════════════════════════════════════
  String _colType() {
    final n = widget.college.collegeName;
    if (n.contains('Government Autonomous')) return 'Government Autonomous';
    if (n.contains('Government')) return 'Government';
    if (n.contains('Un-Aided')) return 'Un-Aided (Private)';
    if (n.contains('Aided')) return 'Aided';
    if (n.contains('Minority')) return 'Minority Institution';
    if (n.contains('University')) return 'University Department';
    return 'Private';
  }

  Widget _card(String title, IconData icon, Widget child) => Container(
    margin: const EdgeInsets.only(bottom: 2),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0,2))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
        child: Row(children: [
          Container(padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: const Color(0xFF1565C0).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, size: 15, color: const Color(0xFF1565C0))),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF1A237E))),
        ])),
      const Divider(height: 1),
      Padding(padding: const EdgeInsets.all(12), child: child),
    ]),
  );

  Widget _row2(IconData icon, String lbl, String val, {bool copy = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 15, color: const Color(0xFF1565C0)),
      const SizedBox(width: 8),
      SizedBox(width: 95, child: Text(lbl, style: const TextStyle(fontSize: 12, color: Colors.black54))),
      Expanded(child: Text(val, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black87))),
      if (copy) GestureDetector(onTap: () => _copy(val, lbl),
          child: const Icon(Icons.copy_rounded, size: 13, color: Colors.grey)),
    ]),
  );

  Widget _cTile(IconData icon, Color col, String lbl, String val,
      {required VoidCallback? onTap, required VoidCallback? onCopy}) =>
    InkWell(onTap: onTap, borderRadius: BorderRadius.circular(10),
      child: Padding(padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(color: col.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, size: 18, color: col)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(lbl, style: const TextStyle(fontSize: 10, color: Colors.black45)),
            Text(val, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                color: onTap != null ? col : Colors.black87)),
          ])),
          if (onCopy != null)
            IconButton(icon: const Icon(Icons.copy_rounded, size: 15, color: Colors.grey),
                onPressed: onCopy, padding: EdgeInsets.zero, constraints: const BoxConstraints())
          else if (onTap != null)
            Icon(Icons.arrow_forward_ios_rounded, size: 12, color: col),
        ])));

  Widget _actBtn(IconData icon, String lbl, Color col, VoidCallback? onTap) => Expanded(
    child: GestureDetector(onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: onTap != null ? col : Colors.grey.shade300,
          borderRadius: BorderRadius.circular(12),
          boxShadow: onTap != null ? [BoxShadow(color: col.withOpacity(0.35), blurRadius: 6)] : []),
        child: Column(children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(height: 3),
          Text(lbl, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
        ]))));

  Widget _div() => const Divider(height: 1, thickness: 0.5, color: Color(0xFFEEEEEE));

  Widget _dot(Color c, String lbl) => Row(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 10, height: 10, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(3))),
    const SizedBox(width: 4),
    Text(lbl, style: const TextStyle(fontSize: 11, color: Colors.black54)),
  ]);
}

class _MapBg extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = const Color(0xFFE3F2FD);
    canvas.drawRect(Rect.fromLTWH(0,0,s.width,s.height), p);
    p.color = const Color(0xFFBBDEFB); p.strokeWidth = 1;
    for (double x = 0; x < s.width; x += 36) canvas.drawLine(Offset(x,0), Offset(x,s.height), p);
    for (double y = 0; y < s.height; y += 36) canvas.drawLine(Offset(0,y), Offset(s.width,y), p);
    p.color = const Color(0xFF90CAF9); p.strokeWidth = 6;
    canvas.drawLine(Offset(0, s.height/2), Offset(s.width, s.height/2), p);
    canvas.drawLine(Offset(s.width/2, 0), Offset(s.width/2, s.height), p);
    p.strokeWidth = 3;
    canvas.drawLine(Offset(s.width*0.25,0), Offset(s.width*0.75,s.height), p);
  }
  @override bool shouldRepaint(_) => false;
}
