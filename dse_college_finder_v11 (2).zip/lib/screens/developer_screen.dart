import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class DeveloperScreen extends StatelessWidget {
  const DeveloperScreen({super.key});

  // ═══════════════════════════════════════════════════════════════
  //  ✏️  CHANGE THESE TO YOUR REAL DETAILS
  // ═══════════════════════════════════════════════════════════════
  static const String _name = 'Parth Hingmire';
  static const String _role = 'Flutter Developer';
  static const String _tagline =
      'Building apps that help Maharashtra students find their dream colleges 🎓';
  static const String _phone = '+918237953530'; // with country code
  static const String _whatsappNo = '+918237953530'; // no '+', no spaces
  static const String _email = 'phingmire14@gmail.com';
  static const String _city = 'latur, Maharashtra';
  static const String _experience = '1+ years Flutter';
  static const String _appMessage =
      'Hi parth sir! 👋\nI am using DSE College Finder. Really helpful app! '
      'I wanted to connect with you regarding the app.';
  // ═══════════════════════════════════════════════════════════════

  Future<void> _open(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not open. Please check the app is installed.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _copy(BuildContext context, String value, String label) {
    Clipboard.setData(ClipboardData(text: value));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          const Icon(Icons.copy_rounded, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Text('$label copied to clipboard'),
        ]),
        backgroundColor: const Color(0xFF1565C0),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      body: CustomScrollView(
        slivers: [
          // ── Gradient Hero AppBar ─────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            stretch: true,
            backgroundColor: const Color(0xFF1565C0),
            iconTheme: const IconThemeData(color: Colors.white),
            title: const Text(
              'Developer',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18),
            ),
            flexibleSpace: FlexibleSpaceBar(
              stretchModes: const [StretchMode.zoomBackground],
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF0A1929),
                      Color(0xFF0D47A1),
                      Color(0xFF1565C0)
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(
                  children: [
                    // Decorative circles
                    Positioned(
                        top: -30,
                        right: -30,
                        child:
                            _decorCircle(140, Colors.white.withOpacity(0.04))),
                    Positioned(
                        bottom: 20,
                        left: -40,
                        child:
                            _decorCircle(120, Colors.white.withOpacity(0.05))),
                    Positioned(
                        top: 60,
                        right: 40,
                        child:
                            _decorCircle(60, Colors.white.withOpacity(0.06))),

                    SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(0, 50, 0, 16),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Avatar
                            Container(
                              width: 92,
                              height: 92,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xFF42A5F5),
                                    Color(0xFF1565C0)
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                border:
                                    Border.all(color: Colors.white, width: 3),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 16,
                                      offset: const Offset(0, 6)),
                                ],
                              ),
                              child: Center(
                                child: Text(
                                  _initials(_name),
                                  style: const TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 14),

                            Text(
                              _name,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                letterSpacing: 0.4,
                              ),
                            ),
                            const SizedBox(height: 5),

                            // Role badge
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 5),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Colors.white24),
                              ),
                              child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.code_rounded,
                                        color: Colors.white70, size: 14),
                                    const SizedBox(width: 6),
                                    Text(_role,
                                        style: const TextStyle(
                                            color: Colors.white, fontSize: 13)),
                                  ]),
                            ),
                            const SizedBox(height: 10),

                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 32),
                              child: Text(
                                _tagline,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: Colors.white60,
                                    fontSize: 12,
                                    height: 1.5),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 4),

                  // ── Quick Info Row ──────────────────────────────────────
                  Row(children: [
                    _quickChip(Icons.location_on_rounded, _city,
                        const Color(0xFF1565C0)),
                    const SizedBox(width: 8),
                    _quickChip(Icons.flutter_dash_rounded, _experience,
                        const Color(0xFF00695C)),
                  ]),
                  const SizedBox(height: 20),

                  // ── Contact Buttons ─────────────────────────────────────
                  _sectionHeader(
                      'Get In Touch', Icons.connect_without_contact_rounded),
                  const SizedBox(height: 12),

                  // WhatsApp — big prominent button
                  _bigContactButton(
                    context,
                    icon: Icons.chat_rounded,
                    label: 'Chat on WhatsApp',
                    sublabel: _phone,
                    color: const Color(0xFF25D366),
                    onTap: () => _open(
                      context,
                      'https://wa.me/$_whatsappNo?text=${Uri.encodeComponent(_appMessage)}',
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Call + WhatsApp message side by side
                  Row(children: [
                    Expanded(
                      child: _smallContactButton(
                        context,
                        icon: Icons.call_rounded,
                        label: 'Call',
                        color: const Color(0xFF1565C0),
                        onTap: () => _open(context, 'tel:$_phone'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _smallContactButton(
                        context,
                        icon: Icons.message_rounded,
                        label: 'SMS',
                        color: const Color(0xFF7B1FA2),
                        onTap: () => _open(
                          context,
                          'sms:$_phone?body=${Uri.encodeComponent(_appMessage)}',
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _smallContactButton(
                        context,
                        icon: Icons.email_rounded,
                        label: 'Email',
                        color: const Color(0xFFE53935),
                        onTap: () => _open(
                          context,
                          'mailto:$_email?subject=DSE College Finder&body=${Uri.encodeComponent(_appMessage)}',
                        ),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 20),

                  // ── Contact Details Card ────────────────────────────────
                  _sectionHeader('Contact Details', Icons.badge_rounded),
                  const SizedBox(height: 12),
                  _card(children: [
                    _contactDetailRow(
                      context,
                      icon: Icons.phone_rounded,
                      iconColor: const Color(0xFF1565C0),
                      label: 'Phone',
                      value: _phone,
                      onTap: () => _open(context, 'tel:$_phone'),
                      onLongPress: () => _copy(context, _phone, 'Phone number'),
                    ),
                    _divider(),
                    _contactDetailRow(
                      context,
                      icon: Icons.chat_rounded,
                      iconColor: const Color(0xFF25D366),
                      label: 'WhatsApp',
                      value: '+$_whatsappNo',
                      onTap: () => _open(context,
                          'https://wa.me/$_whatsappNo?text=${Uri.encodeComponent(_appMessage)}'),
                      onLongPress: () =>
                          _copy(context, '+$_whatsappNo', 'WhatsApp number'),
                    ),
                    _divider(),
                    _contactDetailRow(
                      context,
                      icon: Icons.email_rounded,
                      iconColor: const Color(0xFFE53935),
                      label: 'Email',
                      value: _email,
                      onTap: () => _open(context, 'mailto:$_email'),
                      onLongPress: () => _copy(context, _email, 'Email'),
                    ),
                    _divider(),
                    _contactDetailRow(
                      context,
                      icon: Icons.location_on_rounded,
                      iconColor: const Color(0xFF00695C),
                      label: 'Location',
                      value: _city,
                      onTap: null,
                      onLongPress: () => _copy(context, _city, 'Location'),
                    ),
                  ]),
                  const SizedBox(height: 20),

                  // ── Default Message Preview Card ────────────────────────
                  _sectionHeader('Default Message', Icons.forum_rounded),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: const Color(0xFF25D366).withOpacity(0.3)),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 8,
                            offset: const Offset(0, 3))
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: const Color(0xFF25D366).withOpacity(0.12),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.format_quote_rounded,
                                color: Color(0xFF25D366), size: 18),
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            'Pre-filled WhatsApp message',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1A237E)),
                          ),
                          const Spacer(),
                          GestureDetector(
                            onTap: () => _copy(context, _appMessage, 'Message'),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color:
                                    const Color(0xFF1565C0).withOpacity(0.09),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.copy_rounded,
                                        size: 12, color: Color(0xFF1565C0)),
                                    SizedBox(width: 4),
                                    Text('Copy',
                                        style: TextStyle(
                                            fontSize: 11,
                                            color: Color(0xFF1565C0))),
                                  ]),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 12),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F8E9),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFFA5D6A7)),
                          ),
                          child: Text(
                            _appMessage,
                            style: const TextStyle(
                                fontSize: 13.5,
                                color: Colors.black87,
                                height: 1.6),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () => _open(
                              context,
                              'https://wa.me/$_whatsappNo?text=${Uri.encodeComponent(_appMessage)}',
                            ),
                            icon: const Icon(Icons.send_rounded, size: 17),
                            label: const Text('Send on WhatsApp',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF25D366),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              elevation: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── About Developer ─────────────────────────────────────
                  _sectionHeader(
                      'About the Developer', Icons.person_pin_rounded),
                  const SizedBox(height: 12),
                  _card(children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello! I\'m $_name, a passionate Flutter developer from $_city. '
                            'I built DSE College Finder to help Maharashtra students easily find '
                            'eligible colleges for B.Tech Direct Second Year (DSE) and Diploma '
                            'Polytechnic admissions.\n\n'
                            'This app covers real DTE Maharashtra 2025–26 CAP round cutoff data '
                            'for 333+ engineering colleges and 392+ polytechnics. I hope this '
                            'helps you make the best admission decision! 🙏',
                            style: const TextStyle(
                                fontSize: 13.5,
                                color: Colors.black87,
                                height: 1.65),
                          ),
                          const SizedBox(height: 14),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            _skillChip('Flutter'),
                            _skillChip('Dart'),
                            _skillChip('Firebase'),
                            _skillChip('Android'),
                            _skillChip('Material 3'),
                          ]),
                        ],
                      ),
                    ),
                  ]),
                  const SizedBox(height: 30),

                  // ── Footer ──────────────────────────────────────────────
                  Center(
                    child: Column(children: [
                      Text(
                        'Made with ❤️ for Maharashtra students',
                        style: TextStyle(
                            fontSize: 13,
                            color: Colors.grey.shade600,
                            fontStyle: FontStyle.italic),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '© 2025 $_name · DSE College Finder',
                        style: TextStyle(
                            fontSize: 11, color: Colors.grey.shade400),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Long-press any contact detail to copy',
                        style: TextStyle(
                            fontSize: 10, color: Colors.grey.shade400),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Builder helpers ──────────────────────────────────────────────────────────

  String _initials(String name) {
    final parts = name.trim().split(' ').where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  Widget _decorCircle(double size, Color color) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      );

  Widget _sectionHeader(String title, IconData icon) => Row(children: [
        Icon(icon, size: 18, color: const Color(0xFF1565C0)),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1A237E))),
      ]);

  Widget _quickChip(IconData icon, String label, Color color) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.12),
                  blurRadius: 8,
                  offset: const Offset(0, 3))
            ],
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 6),
            Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: color),
                    overflow: TextOverflow.ellipsis)),
          ]),
        ),
      );

  Widget _card({required List<Widget> children}) => Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: children),
        ),
      );

  Widget _divider() => const Divider(height: 1, indent: 16, endIndent: 16);

  Widget _bigContactButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String sublabel,
    required Color color,
    required VoidCallback onTap,
  }) =>
      Material(
        color: color,
        borderRadius: BorderRadius.circular(16),
        elevation: 4,
        shadowColor: color.withOpacity(0.4),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Row(children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12)),
                child: Icon(icon, color: Colors.white, size: 26),
              ),
              const SizedBox(width: 16),
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text(label,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(sublabel,
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 12)),
                  ])),
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: Colors.white70, size: 16),
            ]),
          ),
        ),
      );

  Widget _smallContactButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) =>
      Material(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 5),
              Text(label,
                  style: TextStyle(
                      color: color, fontSize: 12, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      );

  Widget _contactDetailRow(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    VoidCallback? onTap,
    VoidCallback? onLongPress,
  }) =>
      InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label,
                  style: const TextStyle(fontSize: 11, color: Colors.grey)),
              const SizedBox(height: 2),
              Text(value,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87)),
            ]),
            const Spacer(),
            if (onTap != null)
              Icon(Icons.arrow_forward_ios_rounded, size: 13, color: iconColor),
          ]),
        ),
      );

  Widget _skillChip(String label) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFF1565C0).withOpacity(0.09),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF1565C0).withOpacity(0.2)),
        ),
        child: Text(label,
            style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF1565C0),
                fontWeight: FontWeight.w600)),
      );
}
