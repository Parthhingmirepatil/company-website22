class CollegeModel {
  final String collegeName;
  final String district;
  final String branch;
  final Map<String, Map<String, double>> cutoffs;

  CollegeModel({
    required this.collegeName,
    required this.district,
    required this.branch,
    required this.cutoffs,
  });

  factory CollegeModel.fromJson(Map<String, dynamic> json) {
    final rawCutoffs = json['cutoffs'] as Map<String, dynamic>;
    final Map<String, Map<String, double>> parsed = {};
    rawCutoffs.forEach((round, catMap) {
      final Map<String, double> cats = {};
      (catMap as Map<String, dynamic>).forEach((cat, val) {
        cats[cat] = (val as num).toDouble();
      });
      parsed[round] = cats;
    });
    return CollegeModel(
      collegeName: (json['college_name'] ?? '') as String,
      district: (json['district'] ?? '') as String,
      branch: (json['branch'] ?? '') as String,
      cutoffs: parsed,
    );
  }

  double? getCutoff(String capRound, String category) {
    return cutoffs[capRound]?[category];
  }
}

class PredictionResult {
  final CollegeModel college;
  final double cutoff;
  final double userPercentage;
  final String capRound;
  final String category;

  PredictionResult({
    required this.college,
    required this.cutoff,
    required this.userPercentage,
    required this.capRound,
    required this.category,
  });

  double get margin => userPercentage - cutoff;

  String get chanceLabel {
    if (margin >= 10) return 'Strong Chance';
    if (margin >= 5) return 'Good Chance';
    if (margin >= 2) return 'Moderate';
    return 'Very Tight';
  }
}
