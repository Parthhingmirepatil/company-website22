package com.example.dse_college_finder
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
